using System;
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Reflection;
using XiaWorld;

namespace AssetProcess
{
    public class ImageConverter : EditorWindow
    {
        [MenuItem("Tools/Convert Image")]
        public static void ShowWindow()
        {
            EditorWindow.GetWindow(typeof(ImageConverter), false, "图片资源转换工具", true);
        }

        private string inputFolderPath = "D:/XiaWorld_AssetOpt/XiaWorld/Assets/";

        private void OnGUI()
        {
            GUILayout.BeginVertical();
            {
                GUILayout.BeginHorizontal();
                {
                    inputFolderPath = EditorGUILayout.TextField("Input Folder", inputFolderPath);
                    if (GUILayout.Button("选择待处理资产目录"))
                    {
                        inputFolderPath =
                            EditorUtility.OpenFolderPanel("选择待处理资产目录", inputFolderPath, "*");
                    }
                }
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                {
                    if (GUILayout.Button("ConvertTgaToPNG"))
                    {
                        ConvertImagesTGA(inputFolderPath);
                    }

                    if (GUILayout.Button("ConvertJpgToPng"))
                    {
                        ConvertImagesJPG(inputFolderPath);
                    }
                    
                    if (GUILayout.Button("CompressTexture"))
                    {
                        CompressDirectory(inputFolderPath);
                    }
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.EndVertical();
        }


        public void ConvertImagesTGA(string inputFolderPath)
        {
            if (!string.IsNullOrEmpty(inputFolderPath))
            {
                string[] filePaths = Directory.GetFiles(inputFolderPath, "*.tga", SearchOption.AllDirectories);

                foreach (string filePath in filePaths)
                {
                    ConvertToPng(filePath);
                }

                AssetDatabase.Refresh();
            }
        }

        public static void ConvertImagesJPG(string inputFolderPath)
        {
            if (!string.IsNullOrEmpty(inputFolderPath))
            {
                string[] filePaths = Directory.GetFiles(inputFolderPath, "*.jpg", SearchOption.AllDirectories);

                foreach (string filePath in filePaths)
                {
                    ConvertToPng(filePath);
                }

                AssetDatabase.Refresh();
            }
        }

        private static void ConvertToPng(string filePath)
        {
            // 加载图片文件作为 Texture2D  如果是压缩格式的sprite会处理失败，需要预先处理
            Debug.Log("ConvertToPng___filePath==>" + filePath);
            var file = filePath.Replace("\\", "/");
            var path = AssetPathUtils.FullPath2AssetPath(file);
            var assetImporter = AssetImporter.GetAtPath(path) as TextureImporter;
            if (assetImporter != null && !assetImporter.isReadable)
            {
                assetImporter.isReadable = true;
            }

            Texture2D tex = AssetDatabase.LoadAssetAtPath<Texture2D>(path);

            //将 Texture2D 保存为 PNG 图片
            byte[] pngData = tex.EncodeToPNG();
            if (pngData != null && pngData.Length > 0)
            {
                string pngPath = Path.ChangeExtension(filePath, ".png");
                KLog.Dbg("ConvertToPng==pngPath=={0},filePath=={1}", pngPath, filePath);
                File.WriteAllBytes(pngPath, pngData);
                //删除原来的图片文件
                AssetDatabase.DeleteAsset(filePath);
                AssetDatabase.DeleteAsset(filePath + ".meta");
            }
        }
        
        void CompressDirectory(string filePath) {
            string[] files = Directory.GetFiles(filePath, "*.*", SearchOption.AllDirectories);
            foreach (string fileName in files) {
                var path = fileName.Replace("\\", "/");
                var file = AssetPathUtils.FullPath2AssetPath(path);
                if (Path.GetExtension(file) == ".png" || Path.GetExtension(file) == ".jpg" || Path.GetExtension(file) == ".tga") {
                    CompressTexture(AssetDatabase.LoadAssetAtPath<Texture2D>(file));
                }
            }
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        void CompressTexture(Texture2D texture) {
            string path = AssetDatabase.GetAssetPath(texture);
            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer != null) {
                TextureImporterPlatformSettings setting = importer.GetDefaultPlatformTextureSettings();
                //importer.textureType = TextureImporterType.Default;
                importer.textureCompression = TextureImporterCompression.Compressed;
                importer.maxTextureSize = 2048; //你可以根据需要自定义大小
                importer.alphaIsTransparency = importer.DoesSourceTextureHaveAlpha(); //透明通道是否透明
                
                
                
                TextureImporterPlatformSettings iOSSettings = importer.GetPlatformTextureSettings("iPhone");
                iOSSettings.overridden = true;
                iOSSettings.maxTextureSize = setting.maxTextureSize;
                bool isPowerOfTwo = IsPowerOfTwo(texture);
                TextureImporterFormat defaultAlpha = isPowerOfTwo
                    ? TextureImporterFormat.PVRTC_RGBA4
                    : TextureImporterFormat.ASTC_4x4;
                TextureImporterFormat defaultNotAlpha =
                    isPowerOfTwo ? TextureImporterFormat.PVRTC_RGB4 : TextureImporterFormat.ASTC_6x6;
                iOSSettings.format = importer.DoesSourceTextureHaveAlpha() ? defaultAlpha : defaultNotAlpha;
                importer.SetPlatformTextureSettings(iOSSettings);

                TextureImporterPlatformSettings androidSettings = importer.GetPlatformTextureSettings("Android");
                if (androidSettings.overridden)
                {
                    if(androidSettings.format != TextureImporterFormat.ETC2_RGB4 &&
                       androidSettings.format != TextureImporterFormat.ETC2_RGBA8 &&
                       androidSettings.format != TextureImporterFormat.ETC_RGB4 && 
                       androidSettings.format != TextureImporterFormat.ETC2_RGBA8Crunched &&
                       androidSettings.format != TextureImporterFormat.ETC_RGB4Crunched)
                    {
                        KLog.Dbg(path + "==>Android平台没有使用Etc2");
                    } 
                }
                else
                {
                    var format = importer.GetAutomaticFormat("Android");
                    if (format != TextureImporterFormat.ETC2_RGB4 &&
                        format != TextureImporterFormat.ETC2_RGBA8 &&
                        androidSettings.format != TextureImporterFormat.ETC_RGB4 && 
                        androidSettings.format != TextureImporterFormat.ETC2_RGBA8Crunched &&
                        androidSettings.format != TextureImporterFormat.ETC_RGB4Crunched)
                    {
                        KLog.Dbg(path + "==>Android平台没有使用Etc2");
                    }
                }
                androidSettings.overridden = true;
                //androidSettings.allowsAlphaSplitting = false;
                androidSettings.maxTextureSize = setting.maxTextureSize;
                bool divisible4 = IsDivisibleOf4(texture);
                defaultAlpha = divisible4 ? TextureImporterFormat.ETC2_RGBA8Crunched : TextureImporterFormat.ASTC_4x4;
                defaultNotAlpha = divisible4 ? TextureImporterFormat.ETC_RGB4Crunched : TextureImporterFormat.ASTC_6x6;
                androidSettings.format = importer.DoesSourceTextureHaveAlpha() ? defaultAlpha : defaultNotAlpha;
                importer.SetPlatformTextureSettings(androidSettings);
                importer.SaveAndReimport();
                
            }
        }
        
        /// <summary>
        /// 是否2的次幂
        /// </summary>
        /// <param name="importer"></param>
        /// <returns></returns>
        bool IsPowerOfTwo(TextureImporter importer)
        {
            (int width, int height) = GetTextureImporterSize(importer);
            return (width == height) && (width > 0) && ((width & (width - 1)) == 0);
        }

        /// <summary>
        /// 是否2的次幂
        /// </summary>
        /// <param name="texture"></param>
        /// <returns></returns>
        bool IsPowerOfTwo(Texture2D texture)
        {
            return (texture.width == texture.height) && (texture.width > 0) &&
                   ((texture.width & (texture.width - 1)) == 0);
        }

        /// <summary>
        /// 是否被4整除
        /// </summary>
        /// <param name="importer"></param>
        /// <returns></returns>
        bool IsDivisibleOf4(TextureImporter importer)
        {
            (int width, int height) = GetTextureImporterSize(importer);
            return (width % 4 == 0 && height % 4 == 0);
        }

        /// <summary>
        /// 是否被4整除
        /// </summary>
        /// <param name="texture"></param>
        /// <returns></returns>
        bool IsDivisibleOf4(Texture2D texture)
        {
            return (texture.width % 4 == 0 && texture.height % 4 == 0);
        }

        /// <summary>
        /// 获取图片的尺寸 - 获取的是资源原始尺寸，不是unity内显示的
        /// </summary>
        /// <param name="importer"></param>
        /// <returns></returns>
        (int, int) GetTextureImporterSize(TextureImporter importer)
        {
            if (importer != null)
            {
                object[] args = new object[2];
                MethodInfo mi = typeof(TextureImporter).GetMethod("GetWidthAndHeight",
                    BindingFlags.NonPublic | BindingFlags.Instance);
                mi.Invoke(importer, args);
                return ((int)args[0], (int)args[1]);
            }

            return (0, 0);
        }
        
    }
}