#if UNITY_EDITOR
using System;
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace AssetProcess
{
    public class XmlToCSharpConverter : EditorWindow
    {
        private string folderPath = "";

        [MenuItem("Tools/Xml2CSharp Converter")]
        public static void ShowWindow()
        {
            GetWindow(typeof(XmlToCSharpConverter));
        }

        void OnGUI()
        {
            GUILayout.Label("XML to C# Converter", EditorStyles.boldLabel);

            folderPath = EditorGUILayout.TextField("XML Folder Path", folderPath);

            if (GUILayout.Button("Select Folder"))
            {
                folderPath = EditorUtility.OpenFolderPanel("Select XML folder", "", "");
            }

            if (GUILayout.Button("Convert XMLs to C#"))
            {
                ConvertXmlToCSharp(folderPath);
            }
        }

        private void ConvertXmlToCSharp(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                Debug.LogError("Path is invalid.");
                return;
            }

            DirectoryInfo directoryInfo = new DirectoryInfo(path);
            FileInfo[] files = directoryInfo.GetFiles("*.xml");

            foreach (FileInfo file in files)
            {
                XElement root = XElement.Load(file.FullName);
                string className = Path.GetFileNameWithoutExtension(file.Name);
                string classContent = GenerateCSharpClass(root, className);
                string outputPath = Path.Combine(path, className + ".cs");
                File.WriteAllText(outputPath, classContent, Encoding.UTF8);
                Debug.Log($"C# class generated at: {outputPath}");
            }
        }

       private string GenerateCSharpClass(XElement root, string className)
    {
        StringBuilder sb = new StringBuilder();
        Dictionary<string, bool> processedClasses = new Dictionary<string, bool>();

        // Add Usings
        sb.AppendLine("using System.Collections.Generic;");
        sb.AppendLine("using System.Xml.Serialization;");
        sb.AppendLine();
        // Add enums and comments
        //sb.Append(GenerateEnums(root));
        sb.AppendLine();

        // Generate classes
        foreach (XElement element in root.Elements())
        {
            GenerateClass(sb, element, processedClasses, 0);
        }

        return sb.ToString();
    }

       private void GenerateClass(StringBuilder sb, XElement element, Dictionary<string, bool> processedClasses, int indentLevel, XElement parent = null)
       {
           string indent = new string(' ', indentLevel * 4);
           string name = element.Name.LocalName;

           if (element.HasElements)
           {
               if (element.Name == "li")
               {
                   string listItemClassName = $"{element.Parent.Name}";
                   {
                       //sb.AppendLine($"public class {listItemClassName}");
                       //sb.AppendLine($"{}{");
                       processedClasses[listItemClassName] = true;
                       foreach (XElement childElement in element.Elements())
                       {
                           GenerateClass(sb, childElement, processedClasses, 1,element);
                       }
                       //sb.AppendLine($"}}");
                       sb.AppendLine();
                   }

                   // Add the array field to the parent class
                   sb.AppendLine($"{indent}[XmlArray(\"{element.Parent.Name}\")]");
                   sb.AppendLine($"{indent}[XmlArrayItem(\"li\")]");
                   sb.AppendLine($"{indent}public List<{listItemClassName}> {element.Parent.Name};");
               }
               else
               {
                   if (!processedClasses.ContainsKey(name))
                   {
                       sb.AppendLine($"{indent}public class {name}");
                       sb.AppendLine($"{indent}{{");
                       processedClasses[name] = true;
                       foreach (XElement childElement in element.Elements())
                       {
                           GenerateClass(sb, childElement, processedClasses, indentLevel + 1,element);
                       }
                       sb.AppendLine($"{indent}}}");
                       sb.AppendLine();
                   }
               }
              
           }
           else
           {
               // This is a simple type, add the field with serialization attribute
               sb.AppendLine($"{indent}[XmlElement(\"{name}\")]");
               sb.AppendLine($"{indent}public string {name};");
           }
       }
     
     
    }
}
#endif
