using UnityEngine;
using UnityEditor;
using System.IO;
using System.Diagnostics;
using XiaWorld;
using Debug = UnityEngine.Debug;

namespace AssetProcess
{
    public class AudioConverter : EditorWindow
    {
        [MenuItem("Tools/Convert Audio&Video")]
        public static void ShowWindow()
        {
            EditorWindow.GetWindow(typeof(AudioConverter), false, "audio文件转换工具", true);
        }

        private string inputFolderPath = "D:/XiaWorld_AssetOpt/XiaWorld/Assets/";
        private string ffmpegExePath = "C:/Program Files/ffmpeg-5.1.2-full_build/bin/ffmpeg.exe";

        private void OnGUI()
        {
            GUILayout.BeginVertical();
            {

                GUILayout.BeginHorizontal();
                {
                    ffmpegExePath = EditorGUILayout.TextField("ffmpegExePath", ffmpegExePath);
                    if (GUILayout.Button("选择ffmpeg可执行文件"))
                    {
                        ffmpegExePath = EditorUtility.OpenFilePanel("选择ffmpeg可执行文件", "C:/Program Files/", "*");
                    }
                }
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                {
                    inputFolderPath = EditorGUILayout.TextField("asset folder", "D:/XiaWorld_AssetOpt/XiaWorld/Assets");
                    if (GUILayout.Button("选择待处理资产目录"))
                    {
                        inputFolderPath =
                            EditorUtility.OpenFolderPanel("选择待处理资产目录", "D:/XiaWorld_AssetOpt/XiaWorld/Assets", "*");
                    }
                }
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                {
                    if (GUILayout.Button("Convert mp3 to ogg"))
                    {
                        ExecuteConvert("*.mp3", ".ogg");
                    }

                    if (GUILayout.Button("Convert wav to ogg"))
                    {
                        ExecuteConvert("*.wav", ".ogg");
                    }
                }
                GUILayout.EndHorizontal();
                
                GUILayout.BeginHorizontal();
                {
                    inputFolderPath = EditorGUILayout.TextField("asset folder", "D:/XiaWorld_AssetOpt/XiaWorld/Assets/Sound");
                    if (GUILayout.Button("选择音频资产目录"))
                    {
                        inputFolderPath = EditorUtility.OpenFolderPanel("音频资产目录","D:/XiaWorld_AssetOpt/XiaWorld/Assets/Sound","*");
                    }
                    
                    if (GUILayout.Button("将音频资源设置成音声道并根据大小自动设置加载方式"))
                    {
                        ConvertAudioToMono();
                    }
                }
                GUILayout.EndHorizontal();
                
                GUILayout.BeginHorizontal();
                {
                    inputFolderPath = EditorGUILayout.TextField("asset folder", "D:/XiaWorld_AssetOpt/XiaWorld/Assets/Sound");
                    if (GUILayout.Button("选择音频资产目录"))
                    {
                        inputFolderPath = EditorUtility.OpenFolderPanel("音频资产目录","D:/XiaWorld_AssetOpt/XiaWorld/Assets/Sound","*");
                    }
                    
                    if (GUILayout.Button("压缩音频资源"))
                    {
                        ExecuteAudioCompress("*.ogg");
                    }
                }
                GUILayout.EndHorizontal();
                
                GUILayout.BeginHorizontal();
                {
                    inputFolderPath = EditorGUILayout.TextField("asset folder", "D:/XiaWorld_ForAndroidDev/XiaWorld/TeachFile/MP4");
                    if (GUILayout.Button("选择视频资产目录"))
                    {
                        inputFolderPath = EditorUtility.OpenFolderPanel("视频资产目录","D:/XiaWorld_ForAndroidDev/XiaWorld/TeachFile/MP4","*");
                    }
                    
                    if (GUILayout.Button("压缩视频资源"))
                    {
                        ExecuteVideoCompress("*.mp4");
                    }
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.EndVertical();
        }

        private void ExecuteConvert(string srcFilter, string dstFormat)
        {
            if (!string.IsNullOrEmpty(inputFolderPath))
            {
                string[] filePaths = Directory.GetFiles(inputFolderPath, srcFilter, SearchOption.AllDirectories);
                foreach (string inputFilePath in filePaths)
                {
                    var inputFile = inputFilePath.Replace("\\", "/");
                    var assetPath = AssetPathUtils.FullPath2AssetPath(inputFile);
                    var fileName = Path.GetFileNameWithoutExtension(inputFile);
                    var directoryName = Path.GetDirectoryName(inputFile)?.Replace("\\", "/");
                    var outputFile = $"{directoryName}/{fileName}{dstFormat}";
                    ConvertByFFmpeg(inputFile, outputFile);
                    RemoveAsset(assetPath);
                }

                AssetDatabase.Refresh();
                KLog.Dbg2(this, "ExecuteConvert Finished!");
            }
        }

        private void ConvertByFFmpeg(string inputFilePath, string outputFilePath)
        {
            KLog.Dbg2(this, "ConvertMp3ToOgg_inputFilePath=={0}  outputFilePath==>{1}", inputFilePath, outputFilePath);
            Process process = new Process();
            process.StartInfo.FileName = ffmpegExePath;
            process.StartInfo.Arguments = $"-i {inputFilePath} {outputFilePath}";
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.Start();
            process.WaitForExit();
        }

        
        private void ExecuteAudioCompress(string srcFilter)
        {
            if (!string.IsNullOrEmpty(inputFolderPath))
            {
                string[] filePaths = Directory.GetFiles(inputFolderPath, srcFilter, SearchOption.AllDirectories);
                if (filePaths.Length > 0 )
                {
                    Process process = new Process();
                    foreach (string inputFilePath in filePaths)
                    {
                        var inputFile = inputFilePath.Replace("\\", "/");
                        var fileName = Path.GetFileName(inputFile);
                        var directoryName = Path.GetDirectoryName(inputFile)?.Replace("\\", "/");
                        var dir = $"{directoryName}/output/";
                        xasset.Utility.CreateDirectoryIfNecessary(dir);
                        var outputFile = $"{dir}{fileName}";
                        CompressAudioByFFmpeg(process,inputFile, outputFile);
                    }
                    KLog.Dbg2(this, "CompressAudioByFFmpeg_Finished!");
                }
            }
        }

        private void CompressAudioByFFmpeg(Process process,string inputFilePath, string outputFilePath)
        {
            KLog.Dbg2(this, "CompressByFFmpeg_inputFilePath=={0}  outputFilePath==>{1}", inputFilePath, outputFilePath);
            process.StartInfo.FileName = ffmpegExePath;
            process.StartInfo.Arguments = $"-i {inputFilePath} -acodec libvorbis -aq 8 {outputFilePath}";
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.Start();
            process.WaitForExit();
        }
        
        
        
        private void ExecuteVideoCompress(string srcFilter)
        {
            if (!string.IsNullOrEmpty(inputFolderPath))
            {
                string[] filePaths = Directory.GetFiles(inputFolderPath, srcFilter, SearchOption.AllDirectories);
                if (filePaths.Length > 0 )
                {
                    Process process = new Process();
                    foreach (string inputFilePath in filePaths)
                    {
                        var inputFile = inputFilePath.Replace("\\", "/");
                        var fileName = Path.GetFileName(inputFile);
                        var directoryName = Path.GetDirectoryName(inputFile)?.Replace("\\", "/");
                        var dir = $"{directoryName}/output/";
                        xasset.Utility.CreateDirectoryIfNecessary(dir);
                        var outputFile = $"{dir}{fileName}";
                        CompressVideoByFFmpeg(process,inputFile, outputFile);
                    }
                    KLog.Dbg2(this, "CompressVideoByFFmpeg_Done!");
                }
            }
        }

        private void CompressVideoByFFmpeg(Process process,string inputFilePath, string outputFilePath)
        {
            KLog.Dbg2(this, "CompressByFFmpeg_inputFilePath=={0} outputFilePath==>{1}", inputFilePath, outputFilePath);
            process.StartInfo.FileName = ffmpegExePath;
            process.StartInfo.Arguments = $"-i {inputFilePath} -vcodec libx264 -crf 20 {outputFilePath}";
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.Start();
            process.WaitForExit();
        }

        private void RemoveAsset(string assetPath)
        {
            AssetDatabase.DeleteAsset(assetPath);
            AssetDatabase.DeleteAsset(assetPath + ".meta");
        }
        
        private void ConvertAudioToMono()
        {
            // 获取选中的所有对象
            
            var assetGuids = AssetDatabase.FindAssets("t:AudioClip",new string[]{inputFolderPath});

            KLog.Dbg2(this,"assetGuids.length=={assetGuids.Length}");
            
            foreach (var assetGUI in assetGuids)
            {
                var assetPath = AssetDatabase.GUIDToAssetPath(assetGUI);
                var audioClip = AssetDatabase.LoadAssetAtPath<AudioClip>(assetPath);
                // 获取音频文件的导入设置
                AudioImporter audioImporter = (AudioImporter)AssetImporter.GetAtPath(assetPath);
                AudioImporterSampleSettings settings = audioImporter.defaultSampleSettings;
                // Rough estimate of file size based on sample data length
                long sizeInKB = audioClip.samples / 1024;

                if (sizeInKB < 50)
                {
                    settings.loadType = AudioClipLoadType.DecompressOnLoad;
                }
                else if (sizeInKB < 500)
                {
                    settings.loadType = AudioClipLoadType.CompressedInMemory;
                }
                else
                {
                    settings.loadType = AudioClipLoadType.Streaming;
                }

                audioImporter.defaultSampleSettings = settings;
                
                if(audioImporter != null)
                {
                    // 设置为ForceToMono
                    audioImporter.forceToMono = true;
                    // 不要忘记应用更改
                    audioImporter.SaveAndReimport();
                }
            }
            
        }
        
        
    }
}