﻿using UnityEngine;

namespace xasset.example
{
    public class ObjectHolder : MonoBehaviour
    {
        public Object[] objects;
    }
}