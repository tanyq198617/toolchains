﻿using UnityEngine;

namespace xasset.example
{
    public class SplashScreen : MonoBehaviour
    {
    }
}