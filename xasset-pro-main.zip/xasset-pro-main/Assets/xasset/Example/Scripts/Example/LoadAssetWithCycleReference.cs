﻿using System.Collections.Generic;
using UnityEngine;

namespace xasset.example
{
    public class LoadAssetWithCycleReference : MonoBehaviour
    {
        private readonly List<InstantiateObject> objects = new List<InstantiateObject>();

        private Asset _asset;
        private GameObject go;

        private void Start()
        {
            _asset = Asset.Load("Children", typeof(GameObject));
            var prefab = _asset.asset;
            go = Instantiate(prefab) as GameObject;
            objects.Add(InstantiateObject.InstantiateAsync("Children2"));
        }

        private void OnDestroy()
        {
            if (go != null)
            {
                DestroyImmediate(go);
                go = null;
            }

            if (_asset != null)
            {
                _asset.Release();
                _asset = null;
            }

            foreach (var instantiateObject in objects) instantiateObject.Destroy();

            objects.Clear();
        }
    }
}