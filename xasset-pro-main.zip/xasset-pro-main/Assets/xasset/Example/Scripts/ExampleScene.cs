﻿namespace xasset.example
{
    public enum ExampleScene
    {
        Startup,
        Splash,
        OpeningDialog,
        CheckUpdate,
        About,
        Menu,
        GetDownloadSize,
        Async2Sync,
        Additive,
        Download,
        CycleReferences,
        LoadRawAsset
    }
}