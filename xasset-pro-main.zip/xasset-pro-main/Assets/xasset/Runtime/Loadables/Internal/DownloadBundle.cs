﻿using System;
using UnityEngine;

namespace xasset
{
    public class DownloadBundle : Bundle
    {
        private Download _download;
        private AssetBundleCreateRequest _request;

        private byte _retryCount;

        private Step _step = Step.Downloading;

        public static byte RetryTimes { get; set; } = 0;

        public static Func<DownloadBundle, bool> OnDownloadError { get; set; }

        public override void LoadImmediate()
        {
            if (isDone) return;

            while (!_download.isDone) Download.UpdateAll();

            if (_download.status == DownloadStatus.Failed)
            {
                Finish(_download.error);
                return;
            }

            PathManager.SetBundlePathOrURl(info.nameWithAppendHash, _download.info.savePath);
            OnLoaded(_request == null ? LoadAssetBundle(_download.info.savePath) : _request.assetBundle);
            _request = null;
        }

        protected override void OnLoad()
        {
            var downloadInfo = Versions.GetDownloadInfo(info.nameWithAppendHash, info.hash, info.size);
            downloadInfo.encryption = Versions.EncryptionEnabled;
            _download = Download.DownloadAsync(downloadInfo);
        }

        protected override void OnUnused()
        {
            if (_download.isDone) return;
            _download.Cancel();
            Finish("User Cancelled!");
        }

        protected override void OnUpdate()
        {
            if (status != LoadableStatus.Loading) return;

            if (_step == Step.Downloading)
            {
                if (!_download.isDone)
                {
                    progress = _download.downloadedBytes * 1f / _download.info.size * 0.5f;
                    return;
                }

                if (_download.status == DownloadStatus.Failed)
                {
                    if (_retryCount < RetryTimes)
                    {
                        Retry();
                        return;
                    }

                    // 这里可以实现回调函数弹框
                    if (OnDownloadError != null && OnDownloadError(this))
                    {
                        _step = Step.Waiting;
                        return;
                    }

                    Finish(_download.error);
                    return;
                }

                PathManager.SetBundlePathOrURl(info.nameWithAppendHash, _download.info.savePath);
                if (assetBundle != null) return;
                var url = _download.info.savePath;
                _request = LoadAssetBundleAsync(url);
                _step = Step.Loading;
            }
            else
            {
                if (_request == null) return;

                progress = 0.5f + _request.progress;
                if (!_request.isDone) return;

                OnLoaded(_request.assetBundle);
                _request = null;
            }
        }

        public void Retry()
        {
            _download.Retry();
            _retryCount++;
            _step = Step.Downloading;
            Logger.W($"Retry to download {_download.info.url} with {_retryCount} times.");
        }

        private enum Step
        {
            Downloading,
            Loading,
            Waiting
        }
    }
}