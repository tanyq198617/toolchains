﻿namespace xasset
{
    public enum DownloadStatus
    {
        Success,
        Progressing,
        Wait,
        Failed,
        Canceled
    }
}