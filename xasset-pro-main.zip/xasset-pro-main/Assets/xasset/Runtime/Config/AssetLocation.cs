﻿using System;

namespace xasset
{
    [Serializable]
    public class AssetLocation
    {
        public string name;
        public ulong offset;
    }
}