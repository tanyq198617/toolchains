#if UNITY_IOS

using System;
using System.Diagnostics;
using System.IO;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessIOSArchiveAndIpaStep : GSQBuildStep
    {
        private string XcodeScheme
        {
            get { return "Unity-iPhone"; }
        }

        private string XcodeConfiguration
        {
            get { return IsDevelop ? "Debug" : "Release"; }
        }

        private string _archiveDir;

        public string ArchiveDir
        {
            get
            {
                if (string.IsNullOrEmpty(_archiveDir))
                {
                    _archiveDir = $"{BuildSaveDir}/XcodeArchive";
                    var dstDir = new DirectoryInfo(_archiveDir);
                    if (!dstDir.Exists)
                    {
                        dstDir.Create();
                    }
                }

                return _archiveDir;
            }
        }


        private string _xcodeIpaDir;

        public string XcodeIpaDir
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeIpaDir))
                {
                    _xcodeIpaDir = $"{BuildSaveDir}ipa";
                    var dstDir = new DirectoryInfo(_xcodeIpaDir);
                    if (!dstDir.Exists)
                    {
                        dstDir.Create();
                    }
                }

                return _xcodeIpaDir;
            }
        }


        private string _xcodeArchivePath = string.Empty;

        public string XcodeArchivePath
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeArchivePath))
                {
                    _xcodeArchivePath = $"{ArchiveDir}/XiaWorld";
                }

                return _xcodeArchivePath;
            }
        }

        public string IpaExportPathByType(iOSMobileProvisionType provisionType)
        {
            string ipaExportPath = string.Empty;
            switch (provisionType)
            {
                case iOSMobileProvisionType.develop:
                    ipaExportPath = $"{XcodeIpaDir}/Develop";
                    break;
                case iOSMobileProvisionType.adhoc:
                    ipaExportPath = $"{XcodeIpaDir}/Adhoc";
                    break;
                case iOSMobileProvisionType.appstore:
                    ipaExportPath = $"{XcodeIpaDir}/Appstore";
                    break;
            }

            return ipaExportPath;
        }

        public string ProvisioningProfileUuidByType(iOSMobileProvisionType provisionType)
        {
            string profileUuid = string.Empty;
            switch (provisionType)
            {
                case iOSMobileProvisionType.develop:
                    profileUuid = "8a7a47ba-1d1c-4577-86ba-5b330a0e8a83";
                    break;
                case iOSMobileProvisionType.adhoc:
                    profileUuid = "e7648ded-034b-4691-a513-86047de3f68f";
                    break;
                case iOSMobileProvisionType.appstore:
                    profileUuid = "ce539571-5368-477f-a663-23b6111c8b81";
                    break;
            }

            return profileUuid;
        }

        public string ExportOptionsPlistByType(iOSMobileProvisionType provisionType)
        {
            string exportOptionsPlist = string.Empty;
            switch (provisionType)
            {
                case iOSMobileProvisionType.develop:
                    exportOptionsPlist = $"{XcodeConfigDir}Develop/ExportOptions.plist";
                    break;
                case iOSMobileProvisionType.adhoc:
                    exportOptionsPlist = $"{XcodeConfigDir}Adhoc/ExportOptions.plist";
                    break;
                case iOSMobileProvisionType.appstore:
                    exportOptionsPlist = $"{XcodeConfigDir}Appstore/ExportOptions.plist";
                    break;
            }

            return exportOptionsPlist;
        }


        public ProcessIOSArchiveAndIpaStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();

            try
            {
                var result = GSQBuildMgr.SendBuildProgress(StepContent);


                // 清理项目
                string cleanProjCmd =
                    $"xcodebuild clean -project \"{XcodeProjDir}Unity-iPhone.xcodeproj\" -scheme \"{XcodeScheme}\" -configuration \"{XcodeConfiguration}\"";
                var isCleanSuccess = GSQBuildMgr.ExecuteCommand(cleanProjCmd);
                var tipInfo = string.Empty;
                var resultStr = string.Empty;
                if (isCleanSuccess)
                {
                    tipInfo = "清理工程完成";
                    KLog.Dbg2(this, tipInfo);
                    GSQBuildMgr.AppendLog(tipInfo);
                    resultStr = $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">{tipInfo}!</font>\n";
                    GSQBuildMgr.SendBuildProgress(resultStr);
                }
                else
                {
                    tipInfo = "error:清理工程失败 !!!!";
                    SetResult(BuildResult.Failed, tipInfo);
                    resultStr = $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">{tipInfo}!</font>\n";
                    GSQBuildMgr.SendBuildProgress(resultStr);
                    return;
                }


                // 生成archive文件
                string buildXcarchiveCmd =
                    $"xcodebuild archive -project \"{XcodeProjDir}Unity-iPhone.xcodeproj\" -scheme \"{XcodeScheme}\" -archivePath \"{XcodeArchivePath}\" -configuration \"{XcodeConfiguration}\" -destination 'generic/platform=iOS'";
                var isXcArchiveSuccess = GSQBuildMgr.ExecuteCommand(buildXcarchiveCmd);

                if (isXcArchiveSuccess)
                {
                    tipInfo = $"导出 iOS xcarchive 文件完成 SUCCESS!";
                    KLog.Dbg2(this, tipInfo);
                    GSQBuildMgr.AppendLog(tipInfo);
                    resultStr = $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">{tipInfo}!</font>\n";
                    GSQBuildMgr.SendBuildProgress(resultStr); //
                }
                else
                {
                    tipInfo = "error:导出 xcarchive 文件失败！！！！";
                    SetResult(BuildResult.Failed, tipInfo);
                    resultStr = $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">{tipInfo}!</font>\n";
                    GSQBuildMgr.SendBuildProgress(resultStr);
                    return;
                }

                var isSuccess = false;
                if (IsDevelop)
                {
                    isSuccess = exportAchiveAndRenameIpa(iOSMobileProvisionType.develop); //一般不需要生成开发证书ipa，调试期间临时用
                    if (!isSuccess)
                    {
                        SetResult(BuildResult.Failed, "error:生成ipa develop失败!!!!");
                        return;
                    }
                }
                else
                {
                    isSuccess = exportAchiveAndRenameIpa(iOSMobileProvisionType.adhoc);
                    if (!isSuccess)
                    {
                        SetResult(BuildResult.Failed, "error:生成ipa adhoc失败 !!!!");
                        return;
                    }

                    GSQBuildMgr.AppendLog("ProcessIOSArchiveAndIpaStep__IsAppstore==>" + IsAppstore + "   isDevelop==>" +
                                          IsDevelop);
                    if (IsAppstore)
                    {
                        isSuccess = exportAchiveAndRenameIpa(iOSMobileProvisionType.appstore);
                        if (!isSuccess)
                        {
                            SetResult(BuildResult.Failed, "error:生成ipa appstore失败 !!!!");
                            return;
                        }
                    }
                }

                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }


        public bool exportAchiveAndRenameIpa(iOSMobileProvisionType provisionType)
        {
            //生成ipa文件
            var ipaExportPath = IpaExportPathByType(provisionType);
            var exportOptionsList = ExportOptionsPlistByType(provisionType);
            string genIpaCmd =
                $"xcodebuild -exportArchive -archivePath \"{XcodeArchivePath}.xcarchive\"  -exportPath \"{ipaExportPath}\" -exportOptionsPlist \"{exportOptionsList}\" -destination 'generic/platform=iOS'";
            var isGenIpaSuccess = GSQBuildMgr.ExecuteCommand(genIpaCmd);
            var tipInfo = string.Empty;
            var resultStr = string.Empty;
            if (isGenIpaSuccess)
            {
                tipInfo = $"导出  ipa  {provisionType}版 文件完成 SUCCESS!";
                KLog.Dbg2(this, tipInfo);
                GSQBuildMgr.AppendLog(tipInfo);
                resultStr = $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">{tipInfo}!</font>\n";
                GSQBuildMgr.SendBuildProgress(resultStr);
                //重命名 ipa 文件
                string oldBuildName = $"{ipaExportPath}/ProductName.ipa";
                var buildName = string.Empty;
                switch (provisionType)
                {
                    case iOSMobileProvisionType.develop:
                        buildName = $"{FinalBuildName}_develop.ipa";
                        break;
                    case iOSMobileProvisionType.adhoc:
                        buildName = $"{FinalBuildName}_Adhoc.ipa";
                        break;
                    case iOSMobileProvisionType.appstore:
                        buildName = $"{FinalBuildName}_Appstore.ipa";
                        break;
                    default:
                        buildName = $"{FinalBuildName}_Adhoc.ipa";
                        break;
                }

                var renameSuccess = GSQBuildMgr.RenameFile(oldBuildName, buildName);
                if (renameSuccess)
                {
                    tipInfo = $"重命名  ipa {provisionType}版 文件完成 SUCCESS!";
                    KLog.Dbg2(this, tipInfo);
                    GSQBuildMgr.AppendLog(tipInfo);
                    //resultStr = $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">${tipInfo}!</font>\n";
                    //GSQBuildMgr.SendBuildProgress(resultStr);
                }
                else
                {
                    tipInfo = $"error:重命名  ipa {provisionType}版 文件失败 !!!!";
                    KLog.Err2(this, tipInfo);
                    GSQBuildMgr.AppendLog(tipInfo);
                    resultStr = $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">{tipInfo}!</font>\n";
                    GSQBuildMgr.SendBuildProgress(resultStr);
                    return false;
                }

                return true;
            }
            else
            {
                tipInfo = $"error:导出  ipa {provisionType}版 文件失败 !!!!";
                KLog.Err2(this, tipInfo);
                GSQBuildMgr.AppendLog(tipInfo);
                resultStr = $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">{tipInfo}!</font>\n";
                GSQBuildMgr.SendBuildProgress(resultStr);
                return false;
            }
        }


        public override void OnEnd()
        {
            base.OnEnd();
        }


        private float _progress = 0.0f;

        public override float Progress => _progress;
    }
}

#endif