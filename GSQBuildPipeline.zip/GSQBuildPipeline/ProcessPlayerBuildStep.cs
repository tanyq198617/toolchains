using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using XiaWorld;
using xasset.editor;
using Settings = xasset.editor.Settings;
using System.Diagnostics;
using IFix.Editor;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessPlayerBuildStep : GSQBuildStep
    {
        public ProcessPlayerBuildStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }
        
        public override void OnStart()
        {
            base.OnStart();

            try
            {
                var result = GSQBuildMgr.SendBuildProgress(StepContent);
                
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayProgressBar("编译", "准备编译出包", 0f);
				BuildOptions = IsDevelop ? BuildOptions.Development | BuildOptions.AllowDebugging : BuildOptions.None;
#if UNITY_ANDROID
                var buildReport = BuildPipeline.BuildPlayer(new BuildPlayerOptions()
                {
	                scenes = EditorBuildSettingsScene.GetActiveSceneList(EditorBuildSettings.scenes),
	                locationPathName = FinalBuildName,
	                target = BuildTarget.Android,
	                options = BuildOptions
                });
                if (buildReport.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded)
                {

	                var buildFailMsg = $"打包失败 {buildReport.summary.ToString()}";
	                var sendErrMsg = GSQBuildMgr.SendBuildProgress(buildFailMsg);
	                SetResult(BuildResult.Failed,buildFailMsg);
                }
#elif UNITY_IOS
	            var buildReport = BuildPipeline.BuildPlayer(new BuildPlayerOptions()
                {
	                scenes = EditorBuildSettingsScene.GetActiveSceneList(EditorBuildSettings.scenes),
	                locationPathName = XcodeProjDir,
	                target = BuildTarget.iOS,
	                options = BuildOptions
                });
				if (buildReport.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded)
                {

	                var buildFailMsg = $"打包失败 {buildReport.summary.ToString()}";
	                var sendErrMsg = GSQBuildMgr.SendBuildProgress(buildFailMsg);
	                SetResult(BuildResult.Failed,buildFailMsg);
                }
#endif
	            string bundleVersion = PlayerSettings.bundleVersion;
#if UNITY_ANDROID
				if (SystemInfo.operatingSystem.Contains("Windows"))
				{
					//Windows 环境下的代码
					KLog.Dbg2(this,"当前运行的操作系统是 Windows");
					MakeSymbol(AndroidPlayerBuildDir + "/../SO/", FinalBuildName.Replace(".apk",$"-{bundleVersion}-v{GSQBuildMgr.PackNumber}.symbols.zip"), bundleVersion, Path.GetFileNameWithoutExtension(FinalBuildName));
					MakeUpdateTools(FinalBuildName, AndroidPlayerBuildDir + "/../ApkTools/", bundleVersion, Path.GetFileNameWithoutExtension(FinalBuildName));
					
				}
#endif
				
				EditorUtility.ClearProgressBar();
              
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                EditorUtility.ClearProgressBar();
                SetResult(BuildResult.Failed,e.Message);
                throw;
            }
           
        }

		public DirectoryInfo GetClearDir(string dirPath)
		{
			DirectoryInfo verdir = new DirectoryInfo(dirPath);
			if (!verdir.Exists)
			{
				verdir.Create();
			}
			return verdir;
		}

		public void MakeSymbol(string soPath, string zipPath, string version, string szt)
		{
			GSQBuildMgr.AppendLog($"开始处理SO:{zipPath}");
			var soDir = new DirectoryInfo(soPath);
			if (!soDir.Exists)
			{
				soDir.Create();
			}
			//每个apk版本只允许存在一个符号表文件,否则会造成后台数据混乱
			var versionDir = GetClearDir($"{soPath}/{version}/{szt}/SO/");
			FileInfo zipFile = new FileInfo(zipPath);
			if (!zipFile.Exists)
			{
				GSQBuildMgr.AppendLog("未找到符号表文件");
				return;
			}
			if (ZipHelper.UnZip(zipFile.FullName, versionDir.FullName))
			{
				string newZipPath = versionDir.FullName + "/Symbol.zip";
				if (File.Exists(newZipPath))
					File.Delete(newZipPath);
				zipFile.Delete();
				GSQBuildMgr.AppendLog("Zip Success");
			}
			else
				GSQBuildMgr.AppendLog("[Warnning]UnZipSymbolZip Failed");
		}

		public void MakeUpdateTools(string apkFileName, string toolPath, string version, string szt)
		{
			//先生成Bugly工具:
			string mouldBugly = toolPath + "/Mould/bugly.bat";
			if (!File.Exists(mouldBugly))
			{
				GSQBuildMgr.AppendLog("[ERROR]Cant Find Bugly Mould File");
			}
			else
			{
				StreamWriter cmdBat = null;
				try
				{
					var versionDir = $"{toolPath}/../SO/{version}/{szt}/";
					string text = File.ReadAllText(mouldBugly);
					string cmd = text.Replace("[Version]", version)
						.Replace("[BundleID]", PlayerSettings.applicationIdentifier);
					cmdBat = File.CreateText(versionDir + "bugly.bat");
					cmdBat.Write(cmd);
				}
				catch (Exception e)
				{
					GSQBuildMgr.AppendLog($"[ERROR]{e}");
				}
				finally
				{
					cmdBat.Close();
					cmdBat.Dispose();
				}
				try
				{
					string batchFilePath = $"{toolPath}/../SO/{version}/{szt}/bugly.bat";
					Process process = new Process();
					process.StartInfo.FileName = "cmd.exe";
					process.StartInfo.Arguments = $"/c \"{batchFilePath}\"";
					process.Start();
				}
				catch (Exception e)
				{
					GSQBuildMgr.AppendLog("符号表自动上传失败,请手动上传");
				}
			}
			GSQBuildMgr.AppendLog("MakeTools Success");
		}

		public override void OnEnd()
        {
            //TODO
            base.OnEnd();
        }


        private float _progress = 0.0f;

        public override float Progress => _progress;
    }
}