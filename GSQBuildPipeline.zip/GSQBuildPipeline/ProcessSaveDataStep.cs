using System;
using System.IO;
using System.Linq;
using XiaWorld;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessSaveDataStep : GSQBuildStep
    {
        private string shsavedataName = "shsaves";

        public ProcessSaveDataStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();

            try
            {
                string path = shsavedataName;
                path = GFileUtil.LocateFile(path);
                DirectoryInfo dir = new DirectoryInfo(path);
                if (!dir.Exists) return;
                var allUserDir = dir.GetDirectories();
                allUserDir.Append(dir);
                for (var i = 0; i < allUserDir.Length; i++)
                {
                    var userDir = allUserDir[i];
                    var uid = userDir.Name;
                    var infoFile = userDir.GetFiles("*.info");
                    if (infoFile.Length != 0)
                    {
                        GameUlt.DoBindFileHeadToUser(infoFile[0].FullName, uid);
                    }

                    var gsaveFile = userDir.GetFiles("*.gsave");
                    if (gsaveFile.Length != 0)
                    {
                        GameUlt.DoBindFileHeadToUser(gsaveFile[0].FullName, uid);
                    }

                    var saveFile = userDir.GetFiles("*.save");
                    for (var j = 0; j < saveFile.Length; j++)
                    {
                        SaveMgr.DoBindToUser(saveFile[j].FullName, uid);
                    }

                    var setFile = userDir.GetFiles("*.set");
                    if (setFile.Length != 0)
                    {
                        if (setFile[0].Name.Contains("Local_Player")) continue;
                        GameUlt.DoBindFileHeadToUser(setFile[0].FullName, uid);
                        string local = $"{userDir.FullName}/Local_Player.set";
                        if (File.Exists(local))
                            File.Delete(local);
                        File.Copy(setFile[0].FullName, local, true);
                        _progress = (float)i / allUserDir.Length;
                    }
                }

                if (GEnv.zipSaves)
                {
                    if (string.IsNullOrEmpty(GameWatch.shsaveName)) return;
                    var savespath = GFileUtil.LocateFile(GameWatch.shsaveName);
                    var topath = new DirectoryInfo("../saves").FullName;
                    GSQBuildMgr.CopyDirectory(savespath, topath);
                    string shsavePath = string.Format(AssetPathUtils.AssetPathPrefix + "{0}.bytes", GameWatch.shsaveName);
                    ZipHelper.ZipDirectory(topath, GFileUtil.LocateFile(shsavePath));
                    new DirectoryInfo(topath).Delete(true);
                }

                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }


        public override void OnEnd()
        {
            base.OnEnd();
        }

        private float _progress = 0.0f;
        public override float Progress => _progress;
    }
}