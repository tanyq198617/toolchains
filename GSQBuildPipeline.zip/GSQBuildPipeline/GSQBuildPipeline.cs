using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Code.Editor.GSQBuildPipeline
{
    public class GSQBuildPipeline
    {
        private Queue<GSQBuildStepBase> _waitBuildQueue = new Queue<GSQBuildStepBase>();
        private List<GSQBuildStepBase> _allSteps = new List<GSQBuildStepBase>();
        private bool _run = false;
        public bool IsDone
        {
            get { return _waitBuildQueue.Count <= 0; }
        }

        private GSQBuildStepBase _current { get; set; }
        public GSQBuildStepBase Current => _current;
        public Action<bool> FinishCallback { get; set; }

       private float _currStartTime = 0;
        

        public GSQBuildStepBase RegisterStep(GSQBuildStepBase step)
        {
            _allSteps.Add(step);
            _waitBuildQueue.Enqueue(step);
            return step;
        }
        public void Start()
        {
            _run = true;
        }
        public void Cancel()
        {
            _run = false;
            var saved = FinishCallback;
            FinishCallback -= saved;
            FinishCallback = null;
            _waitBuildQueue?.Clear();
            _waitBuildQueue = null;
            _allSteps?.Clear();
            _allSteps = null;
            _current?.Cancel();
            _current = null;
        }

        public void End()
        {
            Cancel();
            _current?.OnEnd();
        }

        public void Run()
        {
            if (!_run)
            {
                return;
            }

            try
            {
                while (_run && _waitBuildQueue.Count > 0)
                {
                    GSQBuildStepBase task = _waitBuildQueue.Dequeue();
                    _current = task;
                    if (task.IsAllDepsReady)
                    {
                        _currStartTime = Time.realtimeSinceStartup;
                        task.Start();
                        if (task.IsDone)
                        {
                            task.Complete();
                            _current.CostTime = Time.realtimeSinceStartup - _currStartTime;
                            continue;
                        }
                        else
                        {
                            _waitBuildQueue.Enqueue(task);
                            break;
                        }
                    }
                    else
                    {
                        _waitBuildQueue.Enqueue(task);
                    }
                }

                if (_waitBuildQueue?.Count <= 0 && _current.IsDone)
                {
                    FinishCallback?.Invoke(true);
                }
              
            }
            catch (Exception e)
            {
                GSQBuildMgr.AppendLog(e.Message);
                Cancel();
            }
          
        }
        
        public string DumpTimeInfo()
        {
            var builder = new StringBuilder();
            foreach (var step in _allSteps)
            {
                builder.AppendLine($"{step.Name}, {step.IsDone}, {step.CostTime}");
            }

            builder.AppendLine("<=====================OnBuildFinished=====================>");
            return builder.ToString();
        }
    }
}