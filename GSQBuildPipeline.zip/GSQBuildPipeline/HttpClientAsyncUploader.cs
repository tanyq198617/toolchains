using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using UnityEngine;


namespace Code.Editor.GSQBuildPipeline
{
    public class HttpClientAsyncUploader : HttpContent
    {
        private const int defaultBufferSize = 4096;
        private Stream content;
        private int bufferSize;
        private Action<long, long> progress;

        public HttpClientAsyncUploader()
        {
            
        }

        public HttpClientAsyncUploader(Stream content, Action<long, long> progress) : this(content, defaultBufferSize, progress)
        {
        }

        public HttpClientAsyncUploader(Stream content, int bufferSize, Action<long, long> progress)
        {
            if (content == null) throw new ArgumentNullException("content");
            if (bufferSize <= 0) throw new ArgumentOutOfRangeException("bufferSize");

            this.content = content;
            this.bufferSize = bufferSize;
            this.progress = progress;
        }

        protected override async Task SerializeToStreamAsync(Stream stream, TransportContext context)
        {
            var buffer = new Byte[this.bufferSize];
            var size = content.Length;
            var uploaded = 0;

            using (this.content)
            {
                int read;
                while ((read = await this.content.ReadAsync(buffer, 0, buffer.Length)) != 0)
                {
                    uploaded += read;
                    progress?.Invoke(uploaded, size);
                    await stream.WriteAsync(buffer, 0, read);
                }
            }
        }

        protected override bool TryComputeLength(out long length)
        {
            length = content.Length;
            return true;
        }

        private string _assetLocalPath = "";
        private string _assetUploadUrl = "";

        public async Task UploadAsync(string assetLocalPath, string assetUploadUrl)
        {
            _assetLocalPath = assetLocalPath;
            _assetUploadUrl = assetUploadUrl;
            if (Directory.Exists(_assetLocalPath))
            {
                string[] files = Directory.GetFiles(_assetLocalPath);

                using (HttpClient client = new HttpClient())
                {
                    foreach (string file in files)
                    {
                        using (var fileStream = File.OpenRead(file))
                        {
                            using (var content = new MultipartFormDataContent())
                            {
                                content.Add(new HttpClientAsyncUploader(fileStream,
                                        (sent, total) =>
                                        {
                                            double percentage = ((double)sent / total) * 100;
                                            Debug.Log($"Uploaded {sent} of {total}. ({percentage}%)");
                                        }),
                                    "file",
                                    Path.GetFileName(file)
                                );

                                HttpResponseMessage response = await client.PostAsync(_assetUploadUrl, content);
                                string responseString = await response.Content.ReadAsStringAsync();

                                if (response.IsSuccessStatusCode)
                                {
                                    Debug.Log("Server Response for file " + file + ": " + responseString);
                                }
                                else
                                {
                                    Debug.LogError("Failed to upload file at path: " + file + ". Server response: " +
                                                   responseString);
                                }
                            }
                        }
                    }
                    
                    
                    // 递归地遍历并上传子目录中的所有文件
                    foreach (var directory in Directory.GetDirectories(_assetLocalPath))
                    {
                        await UploadAsync(directory, _assetUploadUrl);
                    }
                }
            }
            else
            {
                Debug.LogError("Directory not found at path: " + _assetLocalPath);
            }
        }
    }
}