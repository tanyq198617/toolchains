using System;
using System.Diagnostics;
using System.IO;
using IFix;
using IFix.Editor;
using UnityEditor.Compilation;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessIFixInjectStep  : GSQBuildStep
    {

        private bool isFirstpassDllFinished = false;
        private bool isAssemblyCSharpDllFinished = false;
        private bool isFirstpassDllTwoFinished = false;
        private bool isAssemblyCSharpDllTwoFinished = false;
        public ProcessIFixInjectStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
            
        }
        

        // 当一个程序集编译完成时会调用这个回调函数

        private  void OnAssemblyCompilationFinished(string assemblyPath, CompilerMessage[] compilerMessages)
        {
            if (assemblyPath.Contains("Assembly-CSharp-firstpass.dll") || assemblyPath.Contains("Assembly-CSharp.dll"))
            {
                GSQBuildMgr.AppendLog($"执行到了 OnAssemblyCompilationFinished");
                var hasError = false;
                foreach (var message in compilerMessages)
                {
                    if (message.type == CompilerMessageType.Error)
                    {
                        hasError = true;
                        SetResult(BuildResult.Failed, $"编译出错: {assemblyPath}，message=>{message.message}");
                        break;
                    }
                }

                if (!hasError)
                {
                    if (assemblyPath.Contains("ScriptAssemblies/Assembly-CSharp-firstpass.dll"))
                    {
                        GSQBuildMgr.AppendLog($"编译完成: {assemblyPath} time=>{DateTime.Now.ToString("yyyyMMddHHmmss")}");
                        isFirstpassDllFinished = true;
                        
                    }

                    if (assemblyPath.Contains("ScriptAssemblies/Assembly-CSharp.dll"))
                    {
                        GSQBuildMgr.AppendLog($"编译完成: {assemblyPath} time=>{DateTime.Now.ToString("yyyyMMddHHmmss")}");
                        isAssemblyCSharpDllFinished = true;
                    }
                    
                    if (assemblyPath.Contains("PlayerScriptAssemblies/Assembly-CSharp-firstpass.dll"))
                    {
                        GSQBuildMgr.AppendLog($"编译完成: {assemblyPath} time=>{DateTime.Now.ToString("yyyyMMddHHmmss")}");
                        isFirstpassDllTwoFinished = true;
                        
                    }

                    if (assemblyPath.Contains("PlayerScriptAssemblies/Assembly-CSharp.dll"))
                    {
                        GSQBuildMgr.AppendLog($"编译完成: {assemblyPath} time=>{DateTime.Now.ToString("yyyyMMddHHmmss")}");
                        isAssemblyCSharpDllTwoFinished = true;
                    }
                    
                    // 这里执行编译完成后的逻辑
                    try
                    {
                        var allSuccess = isFirstpassDllFinished && isAssemblyCSharpDllFinished && isFirstpassDllTwoFinished && isAssemblyCSharpDllTwoFinished;
                        if (allSuccess)
                        {
                            GSQBuildMgr.AppendLog($"编译完成: allSuccess_{allSuccess} time====>{DateTime.Now.ToString("yyyyMMddHHmmss")}");
                            CompilationPipeline.assemblyCompilationFinished -= OnAssemblyCompilationFinished;
                        }

                    }
                    catch (Exception e)
                    {
                        SetResult(BuildResult.Failed, e.Message);
                        CompilationPipeline.assemblyCompilationFinished -= OnAssemblyCompilationFinished;
                        throw;
                    }
                }
                else
                {
                    SetResult(BuildResult.Failed, $"编译出错: {assemblyPath}，查看编译错误信息以获取更多详情。");
                  
                }

            }
            
        }
        
        public override void OnStart()
        {
            base.OnStart();
            var buildProgress = GSQBuildMgr.SendBuildProgress(StepContent);
            CompilationPipeline.assemblyCompilationFinished += OnAssemblyCompilationFinished;

            SetResult(BuildResult.Success);
        
        }
        
        public override void OnEnd()
        { 
            base.OnEnd();
            
        }

        
        private float _progress = 0.0f;
        public override float Progress => _progress;
        
        
    }
}