using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using XiaWorld;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessSpriteAndTextureLinkStep : GSQBuildStep
    {

        /*private string _texlistPath = string.Empty;
        public string TexListPath
        {
            get
            {
                if (string.IsNullOrEmpty(_texlistPath))
                {
                    _texlistPath = $"{AssetPathUtils.AssetPathPrefix}res/Sprs/texlist.txt";
                }

                return _texlistPath;
            }
        }
        private string[] _resSprsFolders =  new string[] { "res/Sprs", "res/Sprs_lod1", "res/Sprs_lod2" };
        */
        public ProcessSpriteAndTextureLinkStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();

            try
            {
                var geneResult = GSQBuildMgr.GenerateSpriteAndTextureLink();
                AssetDatabase.Refresh();
                if (geneResult)
                {
                    SetResult(BuildResult.Success);
                    KLog.Dbg2(this, "GenerateSprTexLink_Done!");
                }
                else
                {
                    SetResult(BuildResult.Failed, "GenerateSprTexLink_Failed");
                    throw new SystemException("GenerateSprTexLink_Failed");
                }

            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }
    }

}