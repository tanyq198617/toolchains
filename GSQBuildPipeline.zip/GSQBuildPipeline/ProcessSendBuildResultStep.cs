using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessSendBuildResultStep : GSQBuildStep
    {
        public ProcessSendBuildResultStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }


        public override void OnStart()
        {
            base.OnStart();
            try
            {
                var contentStr = string.Empty;
#if UNITY_ANDROID
                if (SystemInfo.operatingSystem.Contains("Windows"))
                {
                    switch (LoginSdkType)
                    {
                        
                        case SdkType.Mango:
                            contentStr =
                                $"<font color=\"info\">#{GSQBuildMgr.SdkTypeStr} 版本构建成功!</font>\n **版本下载连接**：[点击打开内网下载目录](file://WINDOWS-KLRFUIC/Apk), 外网可通过GSQ小助手直接下载";
                            break;
                        case SdkType.GooglePlay:
                            contentStr =
                                $"<font color=\"info\">#{GSQBuildMgr.SdkTypeStr} 版本构建成功!</font>\n **版本下载连接**：[点击打开内网下载目录](file://WINDOWS-KLRFUIC/Android)";
                            break;
                    }
                }
                else
                {
                    contentStr =
                        $"<font color=\"info\">#{GSQBuildMgr.SdkTypeStr} 版本构建成功!</font>\n **版本下载连接**：[点击打开内网下载目录](http://192.168.0.40:8000/Android/apk/)";
                }
#elif UNITY_IOS
                contentStr = "<font color=\"info\">#{GSQBuildMgr.SdkTypeStr} 版本构建成功!</font>\n **版本下载连接**：[点击打开内网下载目录](http://192.168.0.40:8000/iOS/ipa/Adhoc/)";
#endif
                var result = GSQBuildMgr.SendBuildProgress(contentStr);
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }

        public override void OnEnd()
        {
            base.OnEnd();
        }


        private float _progress = 0.0f;
        public override float Progress => _progress;
    }
}