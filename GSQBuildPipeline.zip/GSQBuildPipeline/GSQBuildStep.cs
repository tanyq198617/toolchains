using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using UnityEditor;
using UnityEngine;
using XiaWorld.ClientCore.Pipeline;

namespace Code.Editor.GSQBuildPipeline
{
    public enum iOSMobileProvisionType
    {
        none = 0,
        develop  = 1,
        adhoc = 2,
        appstore = 3,
    }

    public enum SdkType
    {
        None = 0,
        Bili = 1,
        Mango = 2,
        GooglePlay = 3,
        iOSGameCenter = 4,
    }

 
    public class GSQBuildStep : GSQBuildStepBase
    {
        protected int _step = 0;
        protected float _startTime;

        protected string _descKey;
        protected string _descLoc;

        protected string DescLoc
        {
            get
            {
                if (string.IsNullOrEmpty(_descLoc))
                {
                    _descLoc = TFMgr.Get(_descKey);
                }

                return _descLoc;
            }
        }

#if UNITY_ANDROID
        public string StepContent 
        {
            get
            {
                return $"<font color=\"warning\">#{GSQBuildMgr.SdkTypeStr} 版本构建核心步骤提示</font>\n **当前正在构建**：<font color=\"info\">{Name}</font> ";
            }
        }
          
#elif UNITY_IOS
        public string StepContent =>
            $"<font color=\"warning\">#{GSQBuildMgr.SdkTypeStr} 版本构建核心步骤提示</font>\n **当前正在构建**：<font color=\"info\">{Name}</font> ";
#endif
      
#if UNITY_ANDROID
        public string BuildSuccessContent
        {
            get
            {
                return  $"<font color=\"warning\">#{GSQBuildMgr.SdkTypeStr} 版本构建核心步骤提示</font>\n <font color=\"info\">Great! {Name} 构建成功!</font> ";
            }
        }
       
#elif UNITY_IOS
        public string StepContent =>
            $"<font color=\"warning\">#{GSQBuildMgr.SdkTypeStr} 版本构建核心步骤提示</font>\n **当前正在构建**：<font color=\"info\">Great! {Name} 构建成功!</font> ";
#endif

        public virtual string Description => DescLoc;

        #region Parameter Region
        
        
                
        protected static string _appVersion = "1.1.0";
        public string AppVersion
        {
            get { return _appVersion; }
            set { _appVersion = value; }
        }
        
        //public static long PackNumber;

        protected static string _texturePackerexe = null; // texturepacker的exe路径
        public string TexturePackerexe
        {
            get { return _texturePackerexe; }
            set { _texturePackerexe = value; }
        }

        protected static BuildTarget _buildTarget = BuildTarget.iOS;
        public BuildTarget BuildTarget
        {
            get
            {
                return _buildTarget;
            }
            set { _buildTarget = value; }
        }
      

        public static BuildTargetGroup _targetGroup = BuildTargetGroup.iOS;
        public BuildTargetGroup TargetGroup
        {
            get
            {
                return _targetGroup;
            }
            set { _targetGroup = value; }
        }

      
        
        protected static bool _luahotEnable = true; //是否开启lua热更
        public bool LuahotEnable
        {
            get { return _luahotEnable; }
            set { _luahotEnable = value; }
        }
        
        protected static bool _textFix = false; //是否启用特殊和谐文本
        public  bool TextFix
        {
            get { return _textFix; }
            set { _textFix = value; }
            
        }
        
        protected string[] _apkExts = new string[] {"", "_bili", "_mango","_googleplay","_ios_game_center"}; //apk平台相关后缀名;
        public string[] ApkExts
        {
            get { return _apkExts; }

            set { _apkExts = value; }
        }
        
        protected string _packExt = ".mgtv"; //包名扩展
        public string PackExt
        {
            get
            {
                switch (LoginSdkType)
                {
                    case SdkType.Bili:
                        _packExt = ".bili";
                        break;
                    case SdkType.Mango:
                        _packExt = ".mango";    
                        break;
                    case SdkType.GooglePlay:
                        _packExt = ".googleplay";    
                        break;
                    case SdkType.iOSGameCenter:
                        _packExt = ".ios_game_center";    
                        break;
                }
                return _packExt;
            }

            set { _packExt = value; }
        }

        protected string _languageSetting = string.Empty;//语言

        public string LanguageSetting
        {
            get { return _languageSetting; }
            set { _languageSetting = value; }
        }
        
        
        protected static bool _isEnglish = true;
        public bool IsEnglish
        {
            get { return _isEnglish; }
            set { _isEnglish = value; }
            
        }
        
        protected static bool _bsdkOfficial = false; //是否是版署正式版
        public bool BsdkOfficial
        {
            get
            {
                return  _bsdkOfficial;
            }

            set { _bsdkOfficial = value; }
        }
        
        protected static bool _disablePay = false; //是否禁用支付显示入口宏
        public bool DisablePay
        {
            get
            {
                return _disablePay;
            }

            set { _disablePay = value; }
        }
        
        
        protected static SdkType _loginSdkType = SdkType.GooglePlay; //是否要开启sdk 区分mango 1 为bilibili 2为mango 2 为 google play 3 为ios gamecenter
        public SdkType LoginSdkType
        {
            get { return _loginSdkType; }

            set { _loginSdkType = value; }
        }
        
        protected static bool _useUWA = false; //是否打uwa
        public bool UseUWA
        {
            get { return _useUWA; }
            set { _useUWA = value; }
        }
        
        protected static bool _gmEnable = false; //能否启用测试工具
        public bool GmEnable
        {
            get { return _gmEnable; }

            set { _gmEnable = value; }
        }
        
        
        protected static bool _gm2Enable = false; //秘闻事件选择GM窗口
        public bool Gm2Enable
        {
            get
            {
                return _gm2Enable;
            }

            set { _gm2Enable = value; }
        }
        
        protected static bool _devLoading = false; //是否开启优化读档模式
        public bool DevLoading
        {
            get { return _devLoading; }
            set { _devLoading = value; }
        }
        
        
        protected static bool _isOpenSeason = false; //是否开启赛季模式
        public bool IsOpenSeason
        {
            get { return _isOpenSeason; }

            set { _isOpenSeason = value; }
        }
        
        
        protected static bool _testcos = false; //是否使用测试cos桶
        public bool TestCos
        {
            get { return _testcos; }
            set { _testcos = value; }
        }
        
        protected static bool _isEnableProductCos = false; //是否使用测试cos桶
        public bool IsEnableProductCos
        {
            get { return _isEnableProductCos; }
            set { _isEnableProductCos = value; }
        }
        
        
        protected static bool _isConnectTestServer = false; //是否使用测试服务器
        public bool IsConnectTestServer
        {
            get { return _isConnectTestServer; }

            set { _isConnectTestServer = value; }
        }
        
        protected static bool _isEnableSandboxServer = false; //外网沙箱server
        public bool IsEnableSandboxServer
        {
            get { return _isEnableSandboxServer; }

            set { _isEnableSandboxServer = value; }
        }
        
        
        protected static bool _isEnableProductServer = false; //外网正式生产server
        public bool IsEnableProductServer
        {
            get { return _isEnableProductServer; }

            set { _isEnableProductServer = value; }
        }
        
        protected static bool _isOpenTestPay = false; //是否开启android一分钱支付测试
        public bool IsOpenTestPay
        {
            get { return _isOpenTestPay; }
            set { _isOpenTestPay = value; }
        }

        protected static bool _IsRepackTexture = false; // 是否重做图集
        public bool IsRepackTexture
        {
            get { return _IsRepackTexture; }
            set { _IsRepackTexture = value; }
        }

        private string[] _normalJars = new string[]
            {"XiaLibs.jar", "libs/oaid_sdk_1.0.25.aar", "libs/game-oaid-1.0.26.aar",};

        public string[] NormalJars
        {
            get { return _normalJars; }
            set { _normalJars = value; }
        }

        protected string[] _coreMangoJars = new string[]
        {
            "XiaLibs-Mango.jar", "libs/alipaysdk-android_15.8.11.aar", "libs/CN_OAID_4.2.4.aar",
            "libs/gamesdk.aar", "libs/glide-full-4.7.0.jar", "libs/mango_common.aar",
            "libs/mango_core.aar", "libs/mango_mgtv.aar", "libs/wechat-sdk-android-without-mta_6.8.0.aar",
            "libs/oaid_sdk_1.0.25.aar", "libs/game-oaid-1.0.26.aar","com.alibaba_fastjson_1.2.83.jar",
			"libs/okhttp-3.11.0.jar","libs/okio-1.13.0.jar"
		};

        protected string[] _googlePlayJars = new string[]
        {
            "xiaworld_googleplay.jar",
        };
        
        public string[] GooglePlayJars
        {
            get { return _googlePlayJars; }

            set { _googlePlayJars = value; }
        }
        
        public string[] CoreMangoJars
        {
            get { return _coreMangoJars; }

            set { _coreMangoJars = value; }
        }

        
        protected static BuildOptions _buildOptions; //编译平台option选择
        public BuildOptions BuildOptions
        {
            get { return _buildOptions; }

            set { _buildOptions = value; }
        }

        protected string _buildSaveDir = string.Empty; //编译打包输出目录
        public string BuildSaveDir
        {
            get
            {
                if (string.IsNullOrEmpty(_buildSaveDir))
                {
                    _buildSaveDir = $"{Environment.CurrentDirectory}/Build/{xasset.editor.Settings.Platform}/";
                }

                return _buildSaveDir;
            }
        }
        

        protected static bool _isDevelop = false;
        public bool IsDevelop
        {
            get { return _isDevelop; }

            set { _isDevelop = value; }
        }

        protected static ScriptingImplementation _scriptBackend = ScriptingImplementation.IL2CPP;
        public ScriptingImplementation ScriptBackend
        {
            get { return _scriptBackend; }

            set { _scriptBackend = value; }
        }
        
        
        protected static string _buildTypeExt = "_mango";
        public string BuildTypeExt
        {
            get { return _buildTypeExt; }

            set { _buildTypeExt = value; }
        }
        
        protected static string _androidPlayerBuildDir = "../../AmazingCultivationSimulator/Apk/";
        public string AndroidPlayerBuildDir
        {
            get { return _androidPlayerBuildDir; }
            set { _androidPlayerBuildDir = value; }
        }
        
        
        protected string _androidApkDir;

        public string AndroidApkDir
        {
            get
            {
                if (string.IsNullOrEmpty(_androidApkDir))
                {
                    _androidApkDir = $"{BuildSaveDir}apk";
                    GSQBuildMgr.MakeDirectory(_androidApkDir);
                }
                
                return _androidApkDir;
            }
            
        }
        
        
        protected static string _genVersionInfo = string.Empty;
        public string GenVersionInfo
        {
            get
            {
                //if (string.IsNullOrEmpty(_genVersionInfo))
                {
                    var currTimestamp = GetCurrTime();
                    _genVersionInfo = currTimestamp.Substring(3);
                }
                return _genVersionInfo;
            }
        }
        
        protected static bool _enableProduct = false;
        public bool EnableProduct
        {
            get { return _enableProduct; }
            set { _enableProduct = value; }
        }

        /// <summary>
        /// 是否为渠道包
        /// </summary>
        protected static bool _isChannel = false;
        public bool IsChannel
        {
            get { return _isChannel; }
            set { _isChannel = value; }
        }

		#region iOS

		protected static bool _isOnlyObjectCOrSdkChanged = false;
        public bool IsOnlyObjectChanged
        {
            get => _isOnlyObjectCOrSdkChanged;
            set => _isOnlyObjectCOrSdkChanged = value;
        }


        protected static bool _isAppstore = false;
        public bool IsAppstore
        {
            get => _isAppstore;
            set => _isAppstore = value;
        }

        protected string _xcodeConfigDir;
        public string XcodeConfigDir
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeConfigDir))
                {
                    _xcodeConfigDir = $"{Environment.CurrentDirectory}/Build_iOS_Config/";
                    var dstDir = new DirectoryInfo(_xcodeConfigDir);
                    if (!dstDir.Exists)
                    {
                        dstDir.Create();
                    }
                }
                return _xcodeConfigDir;
            }   
        }
      
        protected string _xcodeProjDir = string.Empty;
        public string XcodeProjDir
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeProjDir))
                {
                    var dstDir = new DirectoryInfo(BuildSaveDir);
                    if (!dstDir.Exists)
                    {
                        dstDir.Create();
                    }
                    _xcodeProjDir = $"{BuildSaveDir}AmazingCultivationSimulator_v{AppVersion}/";
                }

                return _xcodeProjDir;
            }
        }
        
        protected string _xcodeEntitlements;
        public string XcodeEntitlements
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeEntitlements))
                {
                    var folder = $"{XcodeProjDir}/Unity-iPhone/";
                    var dstDir = new DirectoryInfo(folder);
                    if (!dstDir.Exists)
                    {
                        dstDir.Create();
                    }
                    _xcodeEntitlements = $"{dstDir}Unity-iPhone.entitlements";
                }
                return _xcodeEntitlements;
            }
        }
        

        protected string _xcodeConfigEntitlements;
        public string XcodeConfigEntitlements
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeConfigEntitlements))
                {
                    _xcodeConfigEntitlements = $"{XcodeConfigDir}Unity-iPhone.entitlements";
                }
                return _xcodeConfigEntitlements;
            }
        }
        
        protected string _xcodeAppController;
        public string XcodeAppController
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeAppController))
                {
                    var folder = $"{XcodeProjDir}Classes";
                    var dstDir = new DirectoryInfo(folder);
                    if (!dstDir.Exists)
                    {
                        dstDir.Create();
                    }
                    _xcodeAppController = $"{dstDir}/UnityAppController.mm";
                }
                return _xcodeAppController;
            }
        }


        
        
        protected string _xcodeConfigAppController;
        public string XcodeConfigAppController
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeConfigAppController))
                {
                    _xcodeConfigAppController = $"{XcodeConfigDir}/UnityAppController.mm";
                }
                return _xcodeConfigAppController;
            }
        }
        
        
        protected string _xcodeUnityIphoneProj;
        public string XcodeUnityIphoneProj
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeUnityIphoneProj))
                {
                    _xcodeUnityIphoneProj = $"{XcodeProjDir}Unity-iPhone.xcodeproj/project.pbxproj";
                }
                return _xcodeUnityIphoneProj;
            }
        }
        
        protected string _xcodeConfigUnityIphoneProj;
        public string XcodeConfigUnityIphoneProj
        {
            get
            {
                if (string.IsNullOrEmpty(_xcodeConfigUnityIphoneProj))
                {
                    if (IsDevelop)
                    {
                        _xcodeConfigUnityIphoneProj = $"{XcodeConfigDir}Develop/Unity-iPhone.xcodeproj/project.pbxproj";
                    }
                    else
                    {
                        _xcodeConfigUnityIphoneProj = $"{XcodeConfigDir}Unity-iPhone.xcodeproj/project.pbxproj";
                    }
                   
                }
                return _xcodeConfigUnityIphoneProj;
            }
        }
        
        
            
        protected string _derivedDataPath = string.Empty;
        public string DerivedDataPath
        {
            get
            {
                if (string.IsNullOrEmpty(_derivedDataPath))
                {
                    var dstDir = new DirectoryInfo(BuildSaveDir);
                    if (!dstDir.Exists)
                    {
                        dstDir.Create();
                    }

                    _derivedDataPath = $"{dstDir}DerivedData";
                }

                return _derivedDataPath;
            }
        }
        
    
        




        #endregion

        protected string _finalBuildName = string.Empty;
        public string FinalBuildName
        {
            get
            {
                if (string.IsNullOrEmpty(_finalBuildName))
                {
                    string languageSuffix = IsEnglish ? "[EN]" : "CN";
                    DirectoryInfo dstDir = null;
                    
                    string serverSuffix = string.Empty;
                    if (EnableProduct)
                    {
                        serverSuffix = "_Product";
                    }
                    else
                    {
                        serverSuffix = "_TestServer";
                    }

                    string isEnableTestPay = IsOpenTestPay ? "_TestPay" : string.Empty;

                    string scriptBackendSuffix = ScriptBackend == ScriptingImplementation.IL2CPP ? "_il2cpp" : "_mono";

                    string buildName =
                        $"AmazingCultivationSimulator_v{AppVersion}_{GSQBuildMgr.PackNumber}_{languageSuffix}_{BuildTypeExt}{serverSuffix}{isEnableTestPay}{scriptBackendSuffix}";

#if UNITY_ANDROID
                    if (SystemInfo.operatingSystem.Contains("Windows"))
                    {
                        // Windows 环境下的代码
                        dstDir = new DirectoryInfo(AndroidPlayerBuildDir);
                    }
                    else
                    {
                        dstDir = new DirectoryInfo(AndroidApkDir);
                    }
                    
                    buildName = $"{dstDir}/{buildName}";

#elif UNITY_IOS
                    dstDir = new DirectoryInfo(BuildSaveDir);
#endif

                    if (!dstDir.Exists)
                    {
                        dstDir.Create();
                    }

                    if (IsDevelop)
                    {
                        buildName = $"{buildName}_dev";
                    }

#if UNITY_ANDROID
                    if (LoginSdkType == SdkType.GooglePlay)
                    {
                        _finalBuildName = $"{buildName}.aab";
                    }
                    else
                    {
                        _finalBuildName = $"{buildName}.apk";
                    }
                   
#elif UNITY_IOS

                    _finalBuildName = buildName;
#endif
                }

                return _finalBuildName;
            }

            set { _finalBuildName = value; }
        }


        public HttpClient client = null;

        #endregion


        public GSQBuildStep(int step, string descriptionKey)
        {
            _step = step;
            if (!string.IsNullOrEmpty(descriptionKey))
            {
                _descKey = descriptionKey;
            }
        }

        public override void OnStart()
        {
            _startTime = Time.realtimeSinceStartup;
            
            GSQBuildMgr.AppendLog($"processing {Name}.OnStart startTime==>{DateTime.Now.ToString("yyyyMMddHHmmss")}");
        }

        public override void OnEnd()
        {
            CostTime = (int) (1000 * (Time.realtimeSinceStartup - _startTime));
            GSQBuildMgr.AppendLog($"processing {Name}.OnEnd endTime==>{DateTime.Now.ToString("yyyyMMddHHmmss")}");
        }

        protected override void OnUpdated()
        {
            throw new NotImplementedException();
        }


        protected string GetCurrTime()
        {
            var currTime = DateTime.Now.ToString("yyyyMMddHHmm");
            return currTime;
        }
    }
}