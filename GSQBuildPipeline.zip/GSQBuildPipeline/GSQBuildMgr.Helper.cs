
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Assets.USecurity;
using ICSharpCode.SharpZipLib.Zip;
using IFix.Editor;
using UnityEditor;
using UnityEngine;
using xasset;
using XiaWorld;

namespace Code.Editor.GSQBuildPipeline
{

    public partial class GSQBuildMgr
    {



        #region Settings目录文件处理

        private static bool ziptest = false;

        private static readonly List<string> copyfile = new List<string>() {"save", "png", "mp4", "12", "jpg", "json"};
        private static string AesPwd = "XiaWorld/Settings/Esoterica/Esoterica_Other.xml";

        private static string XiaWorldUp = "XiaWorld";
        private static string xiaworld = "/xiaworld/";
        private static string XiaWorldSlash = "/XiaWorld/";
        private static string _settings = "Settings";
        private static string _settingsD = "SettingsD";
        private static string _settingSlash = "Settings/";
        private static string _targetConfigSaveDataJson = "TargetConfigSaveData.json";


        private static string _4Zip = "4Zip";
        private static string _scripts = "Scripts";
        private static string _scriptsD = "ScriptsD";
        private static string _scriptSlash = "Scripts/";
        private static string _scriptSrcDir = "XiaWorld/Scripts";
        private static string _scriptDstDir = "XiaWorld/ScriptsD";
        private static string _settingSrcDir = "XiaWorld/Settings";
        private static string _settingDstDir = "XiaWorld/SettingsD";
        private static string _xiaWorldBytes = "XiaWorld.bytes";


        public static bool OnProcessSettingAndScripts()
        {
            try
            {
                if (!ziptest)
                {
                    DoSettingsMaker(true, true, DLC._COUNT);
                }

                var settingFromFolder = GFileUtil.LocateFile(_settingsD);
                var settingDirInfo = new DirectoryInfo(settingFromFolder);
                var pRoot = settingDirInfo.Parent?.Parent;
                var p = new DirectoryInfo(pRoot?.FullName + "/" + _4Zip);

                var settingsToFolder = p.FullName + "/" + _settings;

                var scriptFromFolder = pRoot?.FullName + "/" + _scriptDstDir;
                var scriptToFolder = p.FullName + "/" + _scripts;

                GSQBuildMgr.AppendLog("< p=" + p + " settingFromFolder=" + settingFromFolder + " settingsToFolder=" +
                                      settingsToFolder + " scriptFromFolder=" + scriptFromFolder +
                                      " scriptToFolder==>" + scriptToFolder);

                var zipFile = pRoot?.FullName + XiaWorldSlash + AssetPathUtils.AssetPathPrefix + _xiaWorldBytes;

                if (ziptest)
                {
                    zipFile = pRoot?.FullName + "/" + _xiaWorldBytes;
                }

                if (!ziptest)
                {
                    if (p.Exists)
                        p.Delete(true);
                    p.Create();
                    Directory.Move(settingFromFolder, settingsToFolder);
                    Directory.Move(scriptFromFolder, scriptToFolder);
                }

                ZipHelper.ZipNoTopDirectory(p.FullName, zipFile);
                var zipPath =
                    $"{pRoot?.FullName}{XiaWorldSlash}{AssetPathUtils.AssetPathPrefix}{_targetConfigSaveDataJson}";
                FileChecker.SaveFileInfo(p.FullName + "/", new string[] {"Settings", "Scripts"}, zipPath);
                AssetDatabase.SaveAssets();
                AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{_targetConfigSaveDataJson}",
                    ImportAssetOptions.ForceUpdate);
                AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{_targetConfigSaveDataJson}.meta",
                    ImportAssetOptions.ForceUpdate);
                AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{_xiaWorldBytes}",
                    ImportAssetOptions.ForceUpdate);
                AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{_xiaWorldBytes}.meta",
                    ImportAssetOptions.ForceUpdate);
                AssetDatabase.SaveAssets();

                return true;
            }
            catch (Exception e)
            {
                return false;
            }

            return false;
        }

        public static void DoSettingsMaker(bool copyNodlcFile, bool copyDlcFile, XiaWorld.DLC checkdlcv)
        {
            copyDlcFile = true;
            if (Directory.Exists(GFileUtil.LocateFile(_settingsD)))
                Directory.Delete(GFileUtil.LocateFile(_settingsD), true);
            var files = Directory.GetFiles(GFileUtil.LocateFile(_settingSlash), "*", SearchOption.AllDirectories);
            for (int i = 0; i < files.Length; i++)
            {
                var path = files[i].Replace("\\", "/");

                XiaWorld.DLC dlcv = XiaWorld.DLC._COUNT;
                var isDlcFile = IsDlcFile(path, ref dlcv);

                if (!isDlcFile && !copyNodlcFile)
                    continue;
                if (isDlcFile && !copyDlcFile)
                    continue;
                if (isDlcFile && checkdlcv != XiaWorld.DLC._COUNT && checkdlcv != dlcv)
                    continue;
                string tpath = null;

                if (CheckFileEndsWith(path))
                {
                    tpath = path.Replace(_settingSrcDir, _settingDstDir);
                    GSQBuildMgr.MakeDirectory(tpath);
                    if (!NeedAES(path))
                        File.Copy(path, tpath);
                    else
                    {
                        var txt = GFileUtil.ReadBytes(path, true);
                        txt = Assets.USecurity.AES.Encrypt2Byte(txt, AesPwd);
                        using (var fs = new FileStream(tpath, FileMode.CreateNew))
                        {
                            using (BinaryWriter bw = new BinaryWriter(fs))
                            {
                                bw.Write(new byte[10]);
                                bw.Write(txt);
                            }
                        }
                    }
                }
                else
                {
                    var p = path.Substring(path.LastIndexOf(".") + 1);
                    if (copyfile.Contains(p))
                    {
                        tpath = path.Replace(_settingSrcDir, _settingDstDir);
                        GSQBuildMgr.MakeDirectory(tpath);
                        File.Copy(path, tpath);
                    }
                }
            }

            if (Directory.Exists(GFileUtil.LocateFile(_scriptsD)))
            {
                Directory.Delete(GFileUtil.LocateFile(_scriptsD), true);
            }

            files = Directory.GetFiles(GFileUtil.LocateFile(_scriptSlash), "*", SearchOption.AllDirectories);
            for (int i = 0; i < files.Length; i++)
            {
                var path = files[i].Replace("\\", "/");

                XiaWorld.DLC dlcv = XiaWorld.DLC._COUNT;
                var isDlcFile = IsDlcFile(path, ref dlcv);
                if (!isDlcFile && !copyNodlcFile)
                    continue;
                if (isDlcFile && !copyDlcFile)
                    continue;
                if (isDlcFile && checkdlcv != XiaWorld.DLC._COUNT && checkdlcv != dlcv)
                    continue;
                if (CheckFileEndsWith(path))
                {
                    var tpath = path.Replace(_scriptSrcDir, _scriptDstDir);
                    GSQBuildMgr.MakeDirectory(tpath);
                    if (!NeedAES(path))
                        File.Copy(path, tpath);
                    else
                    {
                        var txt = GFileUtil.ReadBytes(path, true);
                        txt = Assets.USecurity.AES.Encrypt2Byte(txt, AesPwd);
                        using (var fs = new FileStream(tpath, FileMode.CreateNew))
                        {
                            using (BinaryWriter bw = new BinaryWriter(fs))
                            {
                                bw.Write(new byte[10]);
                                bw.Write(txt);
                            }
                        }
                    }
                }
                else
                {
                    var p = path.Substring(path.LastIndexOf(".") + 1);
                    if (copyfile.Contains(p))
                    {
                        var tpath = path.Replace(_scriptSrcDir, _scriptDstDir);
                        GSQBuildMgr.MakeDirectory(tpath);
                        File.Copy(path, tpath);
                    }
                }
            }
        }

        public static bool CheckFileEndsWith(string path)
        {
            return path.ToLower().EndsWith("xml") || path.ToLower().EndsWith("txt") || path.ToLower().EndsWith("lua");
        }


        public static bool NeedAES(string path)
        {
            return true;
        }


        public static bool IsDlcFile(string path, ref DLC dlc)
        {
            var pathLower = path.ToLower();
            var ia = pathLower.LastIndexOf(xiaworld, StringComparison.Ordinal);
            var ib = pathLower.LastIndexOf(xiaworld, StringComparison.Ordinal);
            pathLower = pathLower.Substring(Mathf.Max(ia, ib) + 1);
            var isDlcFile = false;
            if (pathLower.Contains("_dlc_wudang"))
            {
                dlc = DLC.WuDang;
                isDlcFile = true;
            }
            else if (pathLower.Contains("dlc") || pathLower.Contains("panda"))
            {
                dlc = DLC.Panda;
                isDlcFile = true;
            }

            return isDlcFile;
        }

        #endregion




        #region TeachFile目录处理
        
        private static string _teachFile4Zip = "4ZipTeachFile";
        private static string _teachFile = "TeachFile";
        private static string _wallPaper = "WallPaper";
        private static string _teachFileSrcDir = "XiaWorld/TeachFile";
        private static string _wallPaperSrcDir = "XiaWorld/WallPaper";
        private static string _teachfileBytes = "TeachFile.bytes";
        
        public static bool OnProcessTeachFileWallPaper()
        {
            try
            {
                var teachFileFromFolder = GFileUtil.LocateFile(_teachFile);
                
                var teachFileDirInfo = new DirectoryInfo(teachFileFromFolder);
                var pRoot = teachFileDirInfo.Parent?.Parent;
                var p = new DirectoryInfo(pRoot?.FullName + "/" + _teachFile4Zip);
                var teachFileToFolder = p.FullName + "/" + _teachFile;

                var wallPaperFromFolder = pRoot?.FullName + "/" + _wallPaperSrcDir;
                var wallPaperToFolder = p.FullName + "/" + _wallPaper;

                AppendLog("< p=" + p + " teachFileFromFolder=" + teachFileFromFolder +
                                      " teachFileToFolder=" + teachFileToFolder + " wallPaperFromFolder=" +
                                      wallPaperFromFolder + " wallPaperToFolder==>" + wallPaperToFolder);
                
                if (!ziptest)
                {
                    if (p.Exists)
                        p.Delete(true);
                    p.Create();
                    CopyDirectory(teachFileFromFolder, teachFileToFolder);
                    CopyDirectory(wallPaperFromFolder, wallPaperToFolder);
                }

                // 压缩TeachFile目录下的所有子目录
                var subDirectories = Directory.GetDirectories(teachFileToFolder);
                foreach (var subDir in subDirectories)
                {
                    var subDirInfo = new DirectoryInfo(subDir);
                    var zipFileName = $"{_teachFile}_{subDirInfo.Name}.bytes";
                    var zipFilePath = Path.Combine(pRoot?.FullName + XiaWorldSlash + AssetPathUtils.AssetPathPrefix, zipFileName);

                    ZipHelper.ZipDirectory(subDir, zipFilePath,parentFoldName:_teachFile);
                    AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{zipFileName}",
                        ImportAssetOptions.ForceUpdate);
                    AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{zipFileName}.meta",
                        ImportAssetOptions.ForceUpdate);
                }
                
                // 创建一个新的TeachFile目录
                var newTeachFileDir = Path.Combine(teachFileToFolder, _teachFile);
                Directory.CreateDirectory(newTeachFileDir);

                // 将TeachFile目录下的所有文件拷贝到新的TeachFile目录
                var files = Directory.GetFiles(teachFileToFolder);
                foreach (var file in files)
                {
                    var destFile = Path.Combine(newTeachFileDir, Path.GetFileName(file));
                    File.Copy(file, destFile, true);
                }

                // 压缩新的TeachFile目录
                var teachFileZipPath = Path.Combine(pRoot?.FullName + XiaWorldSlash + AssetPathUtils.AssetPathPrefix, $"{_teachFile}.bytes");
                AppendLog($"Compressing {newTeachFileDir} to {teachFileZipPath}");
                ZipHelper.ZipDirectory(newTeachFileDir, teachFileZipPath,parentFoldName:"");

                // 删除新的TeachFile目录
                Directory.Delete(newTeachFileDir, true);
                
                AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{_teachFile}.bytes",
                    ImportAssetOptions.ForceUpdate);
                AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{_teachFile}.meta",
                    ImportAssetOptions.ForceUpdate);

                // 压缩WallPaper目录
                var wallPaperZipPath = Path.Combine(pRoot?.FullName + XiaWorldSlash + AssetPathUtils.AssetPathPrefix, $"{_wallPaper}.bytes");
                AppendLog($"Compressing {wallPaperToFolder} to {wallPaperZipPath}");
                ZipHelper.ZipDirectory(wallPaperToFolder, wallPaperZipPath,parentFoldName:"");
                
                AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{_wallPaper}.bytes",
                    ImportAssetOptions.ForceUpdate);
                AssetDatabase.ImportAsset($"{AssetPathUtils.AssetPathPrefix}{_wallPaper}.meta",
                    ImportAssetOptions.ForceUpdate);
                
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                AppendLog("ProcessTeachFileAndWallPaper_Done=>!");
                return true;
            }
            catch (Exception e)
            {
                AppendLog("ProcessTeachFile_e=>" + e.Message);
                return false;
            }

        }
        
        
        #endregion


        #region Settings目录文件热更bundle接口

        public static void BuildSettingsBundles()
        {
            var bRet = OnProcessSettingAndScripts();
            if (bRet)
            {
                xasset.editor.Builder.BuildBundlesWithLastBuild();
            }
        }

        #endregion


        #region Res目录图集链接变化热更

        public static void BuildResTexListBundles()
        {
            var bRet = GenerateSpriteAndTextureLink();
            if (bRet)
            {
                xasset.editor.Builder.BuildBundlesWithLastBuild();
            }
        }

        #endregion


        #region 散图资产热更

        public static void BuildNormalAssetsBundles()
        {
            xasset.editor.Builder.BuildBundlesWithLastBuild();
        }

        #endregion

        #region 不区分资产类型，全量资产构建热更

        public static void GSQBuildAllAssetBundles()
        {
            DestroyBuildPipeline();
            PurgeLogFile();

            if (_isSendBuildProgress)
            {
                var args = Environment.GetCommandLineArgs();
                var opts = CommandLine.ParseOpt(args);
                if (opts.Count > 0)
                {
                    var onlyBuildPlayerArg = opts.Find(v => v.Opt == "onlyBuildPlayer")?.Arg;
                    bool.TryParse(onlyBuildPlayerArg, out _isOnlyBuildPlayer);
#if UNITY_IOS
                    var isOnlyObjectCOrSdkChangedArg = opts.Find(v => v.Opt == "isOnlyObjectCOrSdkChanged")?.Arg;
                    Boolean.TryParse(isOnlyObjectCOrSdkChangedArg, out _isOnlyObjectCOrSdkChanged);
                    if (_isOnlyObjectCOrSdkChanged)
                    {
                        _isOnlyBuildPlayer = _isOnlyObjectCOrSdkChanged;
                    }
                    AppendLog("isOnlyObjectCOrSdkChanged==>" + isOnlyObjectCOrSdkChangedArg);
#endif
                }
            }


            _buildPipeline = CreateAssetBuildPipeline();
            _buildPipeline.FinishCallback += OnBuildFinished;
            _buildPipeline.Start();
            _buildPipeline.Run();
        }

        private static GSQBuildPipeline CreateAssetBuildPipeline()
        {
            int step = 1;
            var buildPipeline = new GSQBuildPipeline();
            //var jenkinParamStep = buildPipeline.RegisterStep(new ProcessJenkinParamStep(step++, "ProcessJenkinParamStep")) as ProcessJenkinParamStep;
            var languageStep =
                buildPipeline.RegisterStep(new ProcessLanguageStep(step++, "ProcessLanguageStep")) as
                    ProcessLanguageStep;
            var settingAndScriptStep =
                buildPipeline.RegisterStep(new ProcessSettingAndScriptStep(step++, "ProcessSettingAndScriptStep"))
                    as ProcessSettingAndScriptStep;
            //var teachFileStep = buildPipeline.RegisterStep(new ProcessTeachFileStep(step++, "ProcessTeachFileStep")) as ProcessTeachFileStep;
            var spriteAndTextureLinkStep =
                buildPipeline.RegisterStep(
                        new ProcessSpriteAndTextureLinkStep(step++, "ProcessSpriteAndTextureLinkStep")) as
                    ProcessSpriteAndTextureLinkStep;
            var buildBundleStep =
                buildPipeline.RegisterStep(new ProcessBundleBuildStep(step++, "ProcessBuildBundleStep")) as
                    ProcessBundleBuildStep;
            buildBundleStep?.AddDependency(languageStep, settingAndScriptStep, spriteAndTextureLinkStep);
            return buildPipeline;
        }

        #endregion



        #region InjectFix 生成C#代码热更新补丁

        public async static void GSQBuildGenIFixPatch()
        {
            try
            {
#if UNITY_ANDROID
                var targetName =  "Android";
#elif UNITY_IOS
                var targetName =  "iOS";
#endif
                string progressInfo = progressInfo = $"<font color=\"info\">#{targetName} Generate IFixPatch Start!</font>";
                await SendBuildProgress(progressInfo);
                AppendLog($"{targetName} Generate IFixPatch Start!");
                var path = GFileUtil.LocateFile("/IFixPatch");
/*#if UNITY_EDITOR
                var dir = $"{path}/Editor/";
                IFixEditor.Patch();  
                */
#if UNITY_ANDROID
                var dir = $"{path}/{targetName}/";
                IFixEditor.CompileToAndroid();
#elif UNITY_IOS
                var dir = $"{path}/{targetName}/";
                IFixEditor.CompileToIOS();
#endif
                var subDir = $"{dir}{GEnv.PackVersion}/";
                if (!Directory.Exists(subDir))
                {
                    Utility.CreateDirectoryIfNecessary(subDir);
                }


                GenIFixPatch(subDir, path, dir);
                AppendLog($"{targetName} Generate IFixPatch Success!");
                progressInfo = $"<font color=\"info\">#{targetName} Generate IFixPatch Success!</font>";
                await SendBuildProgress(progressInfo);

            }
            catch (Exception e)
            {
                AppendLog($"Generate IFixPatch_{e.ToString()}");
                var progressInfo = $"<font color=\"info\">#Sorry, Generate IFixPatch Failed!</font>";
                await SendBuildProgress(progressInfo);
                throw;
            }


        }

        public static void GenIFixPatch(string subDir, string path, string dir)
        {
            try
            {

                AppendLog($"GenIFixPatch_subDir=>{subDir}  path=>{path}  dir=>{dir}");
                string[] files = Directory.GetFiles(subDir, "*.patch.bytes", SearchOption.TopDirectoryOnly);
                string zipFolder = path + "/IFixPatchZipDir/";
                var tempDir = zipFolder + "/Encode/"; //加密后的文件暂时放置在Temp文件夹
                DirectoryInfo tDir = new DirectoryInfo(tempDir);
                tDir.Create();
                if (files.Length > 0)
                {
                    var file = files[0];
                    byte[] orginalDatata = File.ReadAllBytes(file);
                    var encryptData = AES.Encrypt2Byte(orginalDatata,
                        "UnityEngine.Networking.DownloadHandlerAssetBundle::Create(UnityEngine.Networking.DownloadHandlerAssetBundle,System.String,System.UInt64)");
                    string newFile = tDir.FullName + Path.GetFileName(file) + ".encode";
                    if (!File.Exists(newFile))
                    {
                        using (var fs = File.Create(newFile))
                        {
                            // The using block will ensure that the FileStream is closed and disposed
                        }
                    }

                    File.WriteAllBytes(newFile, encryptData);
                }

                string zipPath = path + "/IFixPatch.zip";
                if (File.Exists(zipPath))
                {
                    File.Delete(zipPath);
                }

                ZipHelper.ZipNoTopDirectory(zipFolder, zipPath);
                //Copy到各自目录
                string newFilePath = Path.Combine(subDir, "IFixPatch.zip");
                if (File.Exists(newFilePath))
                {
                    File.Delete(newFilePath);
                }

                File.Copy(zipPath, newFilePath, true);
                if (Directory.Exists(zipFolder))
                {
                    Directory.Delete(zipFolder, true);
                }

                if (File.Exists(zipPath))
                {
                    File.Delete(zipPath);
                }

                AppendLog($"GenIFixPatch Success!");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }


        #endregion


        

     

         
        

        [MenuItem("xasset/OnGenerateAPKSFromAppBundle")]
        public static void OnGenerateAPKSFromAppBundle()
        {
            var appBundlePath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.aab".Replace('\\', '/');
            var apksPath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.apks".Replace('\\', '/');
            var toolsPath = $"{Environment.CurrentDirectory}/i18n_build_tools/".Replace('\\', '/');
            GSQBuildMgr.AppendLog($"processApksFromAppBundle_appBundlePath=>{appBundlePath} apksPath=>{apksPath} toolsPath=>{toolsPath}");
            string batCmd = $"BuildI18NApksFromAppBundle.bat \"{appBundlePath}\" \"{apksPath}\" \"{toolsPath}\"";
            GSQBuildMgr.AppendLog($"batCommand=>{batCmd}");
            var isSuccess = GSQBuildMgr.ExecuteBatCommand(batCmd, toolsPath);
            if (isSuccess)
            {
                var successMsg = $"<font color=\"warning\">Great,从app bundle文件导出apks文件成功! 但需要注意APKS文件并非能直接安装的文件，需要使用InstallI18NApks.bat批处理文件安装!</font>\n";
                GSQBuildMgr.AppendLog(successMsg);
            }
            else
            {
                var failMsg = $"<font color=\"error\">Sorry,从app bundle导出APKS文件失败!</font>\n";
                GSQBuildMgr.AppendLog(failMsg);
            }
        }
        
        
        [MenuItem("xasset/OnInstallApkFromAPKS")]
        public static void OnInstallApkFromAPKS()
        {
            var apksPath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.apks".Replace('\\', '/');
            var toolsPath = $"{Environment.CurrentDirectory}/i18n_build_tools/".Replace('\\', '/');
            GSQBuildMgr.AppendLog($"OnInstallApkFromAPKS_a apksPath=>{apksPath} toolsPath=>{toolsPath}");
            string batCmd = $"InstallI18NApks.bat \"{apksPath}\" \"{toolsPath}\"";
            GSQBuildMgr.AppendLog($"batCommand=>{batCmd}");
            var isSuccess = GSQBuildMgr.ExecuteBatCommand(batCmd, toolsPath);
            if (isSuccess)
            {
                var successMsg = $"Great,从apks文件安装成功!</font>";
                GSQBuildMgr.AppendLog(successMsg);
            }
            else
            {
                var failMsg = $"Sorry,从apks文件安装失败!</font>";
                GSQBuildMgr.AppendLog(failMsg);
            }
        }

        
        [MenuItem("xasset/OnGenerateUniversalApksFromAppBundle")]
        public static void OnGenerateUniversalApkFromAppBundle()
        {
            var appBundlePath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.aab".Replace('\\', '/');
            var apksPath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}_universal.apks".Replace('\\', '/');
            var toolsPath = $"{Environment.CurrentDirectory}/i18n_build_tools/".Replace('\\', '/');
            GSQBuildMgr.AppendLog($"OnGenerateUniversalApkFromAppBundle_appBundlePath=>{appBundlePath} apksPath=>{apksPath} toolsPath=>{toolsPath}");
            string batCmd = $"BuildI18NApksFromAppBundle_Universal.bat \"{appBundlePath}\" \"{apksPath}\" \"{toolsPath}\"";
            GSQBuildMgr.AppendLog($"batCommand=>{batCmd}");
            var isSuccess = GSQBuildMgr.ExecuteBatCommand(batCmd, toolsPath);
            if (isSuccess)
            {
                var successMsg = $"Great,从app bundle文件导出universal apks文件成功!";
                GSQBuildMgr.AppendLog(successMsg);
            }
            else
            {
                var failMsg = $"Sorry,从app bundle文件导出universal apks文件失败!";
                GSQBuildMgr.AppendLog(failMsg);
            }
        }
        
        
        [MenuItem("xasset/OnSignAppBundle")]
        public static void OnSignAppBundle()
        {
            var appBundlePath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.aab".Replace('\\', '/');
            //var signedAppBundlePath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}_signed.aab".Replace('\\', '/');
            var toolsPath = $"{Environment.CurrentDirectory}/i18n_build_tools/".Replace('\\', '/');
            GSQBuildMgr.AppendLog($"OnSignAppBundle_appBundlePath=>{appBundlePath} toolsPath=>{toolsPath}");
            string batCmd = $"SignAppBundle.bat \"{appBundlePath}\" \"{toolsPath}\"";
            GSQBuildMgr.AppendLog($"batCommand=>{batCmd}");
            var isSuccess = GSQBuildMgr.ExecuteBatCommand(batCmd, toolsPath);
            if (isSuccess)
            {
                var successMsg = $"Great,app bundle签名成功!";
                GSQBuildMgr.AppendLog(successMsg);
            }
            else
            {
                var failMsg = $"Sorry,app bundle签名失败!";
                GSQBuildMgr.AppendLog(failMsg);
            }
        }
        
        
        [MenuItem("xasset/QueryManifestInfoFromAppBundle")]
        public static void QueryManifestInfoFromAppBundle()
        {
            var appBundlePath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.aab".Replace('\\', '/');
            var toolsPath = $"{Environment.CurrentDirectory}/i18n_build_tools/".Replace('\\', '/');
            GSQBuildMgr.AppendLog($"OnSignAppBundle_appBundlePath=>{appBundlePath} toolsPath=>{toolsPath}");
            string batCmd = $"QueryManifestInfoFromAppBundle.bat \"{appBundlePath}\" \"{toolsPath}\"";
            GSQBuildMgr.AppendLog($"batCommand=>{batCmd}");
            var isSuccess = GSQBuildMgr.ExecuteBatCommand(batCmd, toolsPath);
            if (isSuccess)
            {
                var successMsg = $"Great,manifest查询成功!";
                GSQBuildMgr.AppendLog(successMsg);
            }
            else
            {
                var failMsg = $"Sorry,manifest查询失败!";
                GSQBuildMgr.AppendLog(failMsg);
            }
        }
    }
        
        

}