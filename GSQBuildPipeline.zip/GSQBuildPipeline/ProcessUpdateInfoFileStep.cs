using System;
using System.IO;
using xasset;
using xasset.editor;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessUpdateInfoFileStep : GSQBuildStep
    {
        public ProcessUpdateInfoFileStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();

            try
            {
                /* var path = Settings.PlatformDataPath + "/" + ""; //TODO
                 var versions = Utility.LoadFromFile<Versions>(path);
                 var file = new FileInfo(path);
                 var hash = Utility.ComputeHash(path);
                 Builder.BuildUpdateInfo(versions, hash, file.Length);*/

                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }

        public override void OnEnd()
        {
            base.OnEnd();
        }

        public override string Name { get; }


        private float _progress = 0.0f;
        public override float Progress => _progress;
    }
}