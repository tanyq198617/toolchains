using System;
using System.IO;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessPlayerBuildUploadStep : GSQBuildStep
    {
        
        
        public ProcessPlayerBuildUploadStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();

            try
            {
               /* GSQBuildMgr.AppendLog(FinalBuildName);
                if (!string.IsNullOrEmpty(FinalBuildName) && FinalBuildName.EndsWith(".apk"))
                {
                    var tmpIdx = FinalBuildName.LastIndexOf("/", StringComparison.Ordinal);
                    var buildName = FinalBuildName.Substring(tmpIdx + 1);
                    GSQBuildMgr.AppendLog(buildName);
                    var srcPath = GFileUtil.LocateFile(FinalBuildName);
                    GSQBuildMgr.AppendLog(srcPath);
                    var dstDir = new DirectoryInfo(AndroidPlayerBuildDir);
                    if (!dstDir.Exists)
                    {
                        dstDir.Create();
                    }
                    File.Copy(srcPath, $"{dstDir}/{buildName}",true);
                }*/
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }

        public override void OnEnd()
        {
            //TODO
            base.OnEnd();
        }


        private float _progress = 0.0f;

        public override float Progress => _progress;
    }
}