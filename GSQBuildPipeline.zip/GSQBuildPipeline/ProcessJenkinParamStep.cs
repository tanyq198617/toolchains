using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using XiaWorld;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessJenkinParamStep : GSQBuildStep
    {
        
        public ProcessJenkinParamStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }


        public override void OnStart()
        {
            base.OnStart();

            try
            {
                var sendProgress = GSQBuildMgr.SendBuildProgress(StepContent);
                
                var args = Environment.GetCommandLineArgs();
                var opts = CommandLine.ParseOpt(args);
                if (opts.Count > 0)
                {
                    var versionCodeArg = opts.Find(v => v.Opt == "appVersion")?.Arg;
                    AppVersion = !string.IsNullOrEmpty(versionCodeArg) ? versionCodeArg : PlayerSettings.bundleVersion;

                    TexturePackerexe = opts.Find(v => v.Opt == "texturePackerexe")?.Arg;
                    LoginSdkType = GSQBuildMgr.LoginSdkType;

                    var buildTarget = opts.Find(v => v.Opt == "buildTarget")?.Arg;
                    GSQBuildMgr.AppendLog("buildTarget==>" + buildTarget);
                    switch (buildTarget)
                    {
                        case "Android":
                            BuildTarget = BuildTarget.Android;
                            TargetGroup = BuildTargetGroup.Android;
                            break;
                        case "iOS":
                            BuildTarget = BuildTarget.iOS;
                            TargetGroup = BuildTargetGroup.iOS;
                            break;
                    }

                    var scriptBackend = opts.Find(v => v.Opt == "scriptBackend")?.Arg;
                    GSQBuildMgr.AppendLog("scriptBackend==>" + scriptBackend);
                    switch (scriptBackend)
                    {
                        case "IL2Cpp":
                            ScriptBackend = ScriptingImplementation.IL2CPP;
                            break;
                        case "Mono":
                            ScriptBackend = ScriptingImplementation.Mono2x;
                            break;
                    }


                    var miscArg = opts.Find(v => v.Opt == "msic")?.Arg;
                    if (!string.IsNullOrEmpty(miscArg))
                    {
                        GSQBuildMgr.AppendLog("miscArg==>" + miscArg);
                        var miscParams = miscArg.Split('@');
                        var paramDic = new Dictionary<string, bool>();
                        foreach (var paramKvp in miscParams)
                        {
                            var kvp = paramKvp.Split('=');
                            if (kvp.Length >= 2)
                            {
                                var paramKey = kvp[0].Trim();
                                int.TryParse(kvp[1].Trim(), out var paramV);
                                var paramValue = paramV == 1 ? true : false;
                                paramDic[paramKey] = paramValue;
                            }
                        }

                        var isEn = paramDic["en"];
                        if (isEn || (GSQBuildMgr.LoginSdkType == SdkType.GooglePlay || GSQBuildMgr.LoginSdkType == SdkType.iOSGameCenter))
                        {
                            IsEnglish = true;
                            LanguageSetting = "LANG_EN;";
                        }

                        if (paramDic.ContainsKey("bsdkOfficial"))
                        {
                            BsdkOfficial = paramDic["bsdkOfficial"];
                        }

                        if (paramDic.ContainsKey("uwa"))
                        {
                            UseUWA = paramDic["uwa"];
                        }
                        
                        if (paramDic.ContainsKey("dev_loading"))
                        {
                            DevLoading = paramDic["dev_loading"];
                        }

                        if (paramDic.ContainsKey("isDevelop"))
                        {
                            IsDevelop = paramDic["isDevelop"];
                        }

                        
                        if (paramDic.ContainsKey("isAppstore"))
                        {
                            IsAppstore = paramDic["isAppstore"];
                        }
                        

                        if (paramDic.ContainsKey("isRepackTexture"))
                        {
                            IsRepackTexture = paramDic["isRepackTexture"];
                        }
                        
                        if (paramDic.ContainsKey("enableProduct"))
                        {
                            EnableProduct = paramDic["enableProduct"];
                        }

						if (paramDic.ContainsKey("isChannel"))
						{
							IsChannel = paramDic["isChannel"];
						}
					}
                
                }

                BuildTypeExt = ApkExts[(int)LoginSdkType];
                UpdateAppVersionInfo(); 
                GSQBuildMgr.WritePackVersion();
                AssetDatabase.Refresh();
                GSQBuildMgr.AppendLog($"ProcessJenkinParamStep__GEnv.PackVersion=>{GEnv.PackVersion} packNumber=>{GSQBuildMgr.PackNumber}");
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }
        
        private void UpdateAppVersionInfo()
        {
            PlayerSettings.bundleVersion = AppVersion;
        }


        public override void OnEnd()
        {
            base.OnEnd();
        }

        private float _progress = 0.0f;
        public float Progress => _progress;
    }
}