using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using IFix.Editor;
using UnityEngine;
using xasset.editor;

namespace Code.Editor.GSQBuildPipeline
{
    public enum BuildResult
    {
        Default,
        Success,
        Failed,
        Cancelled
    }

    public enum BuildStatus
    {
        Wait,
        Processing,
        Complete
    }

    public abstract class GSQBuildStepBase : IEnumerator
    {
        public Action<GSQBuildStepBase> completed;
        public BuildResult _result { get; protected set; } = BuildResult.Default;
        public BuildResult Result => _result;
        public BuildStatus _status { get; protected set; } = BuildStatus.Wait;
        public BuildStatus Status => _status;

        public float CostTime = 0;

        private bool _isDone { get; set; }
        public bool IsDone
        {
            get
            {
                return _status == BuildStatus.Complete;
            }
            set
            {
                _isDone = value;
            }
        }

        public virtual string Name => this.GetType()?.Name;
        public virtual float Progress { get; set; }
        public string error { get; protected set; }

        private List<GSQBuildStepBase> _dependencies = new List<GSQBuildStepBase>();
        public List<GSQBuildStepBase> Dependencies => _dependencies;
        public object Current => null;
        
        public StringBuilder _strBuilder = new StringBuilder();
        

        public void AddDependency(params GSQBuildStepBase[] stepBase)
        {
            _dependencies.Clear();
            for (var i = 0; i < stepBase.Length; i++)
            {
                _dependencies.Add(stepBase[i]);
            }
           
        }

        public bool IsAllDepsReady
        {
            get
            {
                if (_dependencies.Count <= 0)
                {
                    return true;
                }
                
                foreach (var dependency in _dependencies)
                {
                    if (!dependency.IsDone)
                    {
                        return false;
                    }
                }
                
                return true;
             
            }
        }

        public bool MoveNext()
        {
            return !IsDone;
        }

        public void Reset()
        {
            completed = null;
            _status = BuildStatus.Wait;
        }

        protected void SetResult(BuildResult value, string msg = null)
        {
            Progress = 1;
            _result = value;
            _status = (_result == BuildResult.Default) ? BuildStatus.Wait : BuildStatus.Complete;
            error = msg;
            switch (value)
            {
                case BuildResult.Success:
                    break;
                case BuildResult.Failed:
                    if (!string.IsNullOrEmpty(error))
                    {
                        _strBuilder.AppendLine($"{Name}, {error}");
                        GSQBuildMgr.AppendLog(_strBuilder.ToString());
                        GSQBuildMgr.BuildPipeline?.Cancel();
                    }   
                    break;
            }
          
           
            
        }

        public void Start()
        {
            if (_status != BuildStatus.Wait) return;
            _status = BuildStatus.Processing;
            OnStart();
        }
        
        public bool Update()
        {
            if (IsDone) return false;
            OnUpdated();
            return true;
        }


        public abstract void OnStart();
        public abstract void OnEnd();

        protected abstract void OnUpdated();
        
        
        public void Complete()
        {
            OnEnd();
            var saved = completed;
            completed?.Invoke(this);
            completed -= saved;
        }

        public void Cancel()
        {
            SetResult(BuildResult.Cancelled);
        }
        
    }
}