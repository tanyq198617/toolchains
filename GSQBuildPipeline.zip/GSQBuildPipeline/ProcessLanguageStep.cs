using System;
using System.IO;
using XiaWorld;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessLanguageStep : GSQBuildStep
    {
        public ProcessLanguageStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();

            try
            {
                string[] langs = new string[] { "cn", "OfficialEnglish" };
                string settingPath = "Settings/Language/{0}/";
                string resourcePath = AssetPathUtils.AssetPathPrefix + "{0}/";
                string configPath = "Language/Config.xml";
                string[] files = new string[]
                {
                    "CodeDictionary.txt",
                    "MapStoryDictionary.txt",
                    "UIText.xml"
                };
                for (int i = 0; i < langs.Length; i++)
                {
                    for (int j = 0; j < files.Length; j++)
                    {
                        string f = GFileUtil.LocateFile(string.Format(settingPath, langs[i]) + files[j]);
                        if (!File.Exists(f)) continue;
                        string rF = GFileUtil.LocateFile(string.Format(resourcePath, langs[i]) + files[j]);
                        if (File.Exists(rF))
                        {
                            File.Delete(rF);
                        }

                        File.Copy(f, rF,true);
                        _progress = (float)i / langs.Length;
                    }
                }

                string c = GFileUtil.LocateFile("Settings/" + configPath);
                if (!File.Exists(c)) return;
                string rc = GFileUtil.LocateFile(AssetPathUtils.AssetPathPrefix + configPath);
                if (File.Exists(rc))
                {
                    File.Delete(rc);
                }

                File.Copy(c, rc,true);
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }

        private float _progress = 0.0f;
        public override float Progress => _progress;


        public override void OnEnd()
        {
            //TODO
            base.OnEnd();
        }
    }
}