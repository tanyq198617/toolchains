using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using XiaWorld;
using xasset.editor;
using Settings = xasset.editor.Settings;
using System.Diagnostics;
using IFix.Editor;
using xasset.pad.editor;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessAppBundleStep : GSQBuildStep
    {
        public ProcessAppBundleStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }
        
        public override void OnStart()
        {
            base.OnStart();

            try
            {
                var sendProgress = GSQBuildMgr.SendBuildProgress(StepContent);
                
                BuildAndroidAssetPacks.BuildAppBundle();
                var buildSuccessContent  = $"<font color=\"warning\">#{GSQBuildMgr.SdkTypeStr} 版本构建核心步骤提示</font>\n <font color=\"info\">Great! {Name} 构建成功! 但请注意,该步编译出来的aab文件并不能直接安装，该文件需要用于上传到google play console后台！</font> ";
                sendProgress = GSQBuildMgr.SendBuildProgress(buildSuccessContent);
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                EditorUtility.ClearProgressBar();
                SetResult(BuildResult.Failed,e.Message);
                throw;
            }
           
        }

        public override void OnEnd()
        {
            base.OnEnd();
        }


        private float _progress = 0.0f;

        public override float Progress => _progress;
    }
}