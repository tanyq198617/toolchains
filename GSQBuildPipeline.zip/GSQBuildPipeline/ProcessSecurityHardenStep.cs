using System;
using System.Diagnostics;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessSecurityHardenStep : GSQBuildStep
    {

        private string _exeFileName = "java";
        public ProcessSecurityHardenStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();
            try
            {
                /*GSQBuildMgr.AppendLog(FinalBuildName);
                if (!string.IsNullOrEmpty(FinalBuildName) && FinalBuildName.EndsWith(".apk"))
                {
                    ProcessStartInfo startInfo = new ProcessStartInfo();
                    startInfo.FileName = "java"; 
                    startInfo.Arguments = $"-jar E:\\GSQ\\YiDunPackNHPProtect.jar -yunconfig -zipalign -apksign -input \"{_toBuildName}\"";
                    startInfo.UseShellExecute = false;

                    Process process = new Process();
                    process.StartInfo = startInfo;
                    process.Start();
                    process.WaitForExit();
                    //string[] @params = new []{"jar","E:\\GSQ\\YiDunPackNHPProtect.jar","yunconfig","zipalign","apksign","input",FinalBuildName};
                    //ExecuteBatchCmd(_exeFileName,@params);
                    string cmd = $"";
                    GSQBuildMgr.ExecuteCommand(cmd);
                }*/

                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }

        public override void OnEnd()
        {
            base.OnEnd();
        }

        private float _progress = 0.0f;
        public override float Progress => _progress;
    }
}