
#if UNITY_IOS

using UnityEditor.iOS.Xcode;
using UnityEditor.iOS.Xcode.Extensions;
using System;
using System.IO;
using XiaWorld;


namespace Code.Editor.GSQBuildPipeline
{
    /*
     * 修改XCode 工程的配置信息
     */
    public class ProcessIOSPbxFileStep : GSQBuildStep
    {


        private string _mangoSdkFramework;

        public string MangoSdkFramework
        {
            get
            {
                if (string.IsNullOrEmpty(_mangoSdkFramework))
                {
                    _mangoSdkFramework = $"{XcodeProjDir}Frameworks/Plugins/iOS/MangoKit.framework";;
                }
                
                return _mangoSdkFramework;
            }
        }
        
            
        private string _reYunFramework;
        public string ReYunFramework
        {
            get
            {
                if (string.IsNullOrEmpty(_reYunFramework))
                {
                    _reYunFramework = $"{XcodeProjDir}Frameworks/Plugins/iOS/ReYunFramework.framework";
                }
                
                return _reYunFramework;
            }
        }
        
        private string _mangoPropertiesConfig;
        public string MangoPropertiesConfig
        {
            get
            {
                if (string.IsNullOrEmpty(_mangoPropertiesConfig))
                {
                    _mangoPropertiesConfig = $"{AssetPathUtils.AssetPluginIOSDir}/mango.properties";
                }
                
                return _mangoPropertiesConfig;
            }
        }
        
        private string _mangoProperties;
        public string MangoProperties
        {
            get
            {
                if (string.IsNullOrEmpty(_mangoProperties))
                {
                    _mangoProperties = $"{XcodeProjDir}Frameworks/Plugins/iOS/mango.properties";
                }
                
                return _mangoProperties;
            }
        }
        
        
        private string _infoPlistConfig;
        public string InfoPlistConfig
        {
            get
            {
                if (string.IsNullOrEmpty(_infoPlistConfig))
                {
                    _infoPlistConfig = $"{_xcodeConfigDir}/Info.plist";
                }
                
                return _infoPlistConfig;
            }
        }
        
        private string _infoPlist;
        public string InfoPlist
        {
            get
            {
                if (string.IsNullOrEmpty(_infoPlist))
                {
                    _infoPlist = $"{XcodeProjDir}/Info.plist";
                }
                
                return _infoPlist;
            }
        }
        
        private string _mangoBundle;
        public string MangoBundle
        {
            get
            {
                if (string.IsNullOrEmpty(_mangoBundle))
                {
                    _mangoBundle = $"{XcodeProjDir}Frameworks/Plugins/iOS/MangoBundle.bundle";
                }
                
                return _mangoBundle;
            }
        }
        
        
        private string _weiboSDKBundle;
        public string WeiboSDKBundle
        {
            get
            {
                if (string.IsNullOrEmpty(_weiboSDKBundle))
                {
                    _weiboSDKBundle = $"{XcodeProjDir}Frameworks/Plugins/iOS/WeiboSDK.bundle";
                }
                
                return _weiboSDKBundle;
            }
        }
        
        private string _tapBillboardBundleSrc;
        public string TapBillboardBundleSrc
        {
            get
            {
                if (string.IsNullOrEmpty(_tapBillboardBundleSrc))
                {
                    _tapBillboardBundleSrc = $"{XcodeProjDir}Frameworks/TapTap/Billboard/Plugins/iOS/Resource/TapBillboardResource.bundle";
                }
                
                return _tapBillboardBundleSrc;
            }
        }
        
        private string _tapBillboardBundleResourceTmp;
        public string TapBillboardBundleResourceTmp
        {
            get
            {
                if (string.IsNullOrEmpty(_tapBillboardBundleResourceTmp))
                {
                    _tapBillboardBundleResourceTmp = $"{XcodeProjDir}TapBillboardResource";
                }
                return _tapBillboardBundleResourceTmp;
            }
        }
        
        
        private string _tapBillboardBundleDst;
        public string TapBillboardBundleDst
        {
            get
            {
                if (string.IsNullOrEmpty(_tapBillboardBundleDst))
                {
                    _tapBillboardBundleDst = $"{XcodeProjDir}TapBillboardResource.bundle";
                }
                
                return _tapBillboardBundleDst;
            }
        }
        
        private string _tapCommonBundleResourceTmp;
        public string TapCommonBundleResourceTmp
        {
            get
            {
                if (string.IsNullOrEmpty(_tapCommonBundleResourceTmp))
                {
                    _tapCommonBundleResourceTmp = $"{XcodeProjDir}TapCommonResource";
                }
                return _tapCommonBundleResourceTmp;
            }
        }
        
        private string _tapCommonBundleSrc;
        public string TapCommonBundleSrc
        {
            get
            {
                if (string.IsNullOrEmpty(_tapCommonBundleSrc))
                {
                    _tapCommonBundleSrc = $"{XcodeProjDir}Frameworks/TapTap/Common/Plugins/iOS/Resource/TapCommonResource.bundle";
                }
                
                return _tapCommonBundleSrc;
            }
        }
        
      
        
        private string _tapCommonBundleDst;
        public string TapCommonBundleDst
        {
            get
            {
                if (string.IsNullOrEmpty(_tapCommonBundleDst))
                {
                    _tapCommonBundleDst = $"{XcodeProjDir}TapCommonResource.bundle";
                }
                
                return _tapCommonBundleDst;
            }
        }
        
        
        private string _tapMomentBundleResourceTmp;
        public string TapMomentBundleResourceTmp
        {
            get
            {
                if (string.IsNullOrEmpty(_tapMomentBundleResourceTmp))
                {
                    _tapMomentBundleResourceTmp = $"{XcodeProjDir}TapMomentResource";
                }
                return _tapMomentBundleResourceTmp;
            }
        }
        
        
        private string _tapMomentBundleSrc;
        public string TapMomentBundleSrc
        {
            get
            {
                if (string.IsNullOrEmpty(_tapMomentBundleSrc))
                {
                    _tapMomentBundleSrc = $"{XcodeProjDir}Frameworks/TapTap/Moment/Plugins/iOS/Resource/TapMomentResource.bundle";
                }
                
                return _tapMomentBundleSrc;
            }
        }
        
        
        private string _tapMomentBundleDst;
        public string TapMomentBundleDst
        {
            get
            {
                if (string.IsNullOrEmpty(_tapMomentBundleDst))
                {
                    _tapMomentBundleDst = $"{XcodeProjDir}TapMomentResource.bundle";
                }
                
                return _tapMomentBundleDst;
            }
        }

        
        private string _tapAchieveBundleResourceTmp;
        public string TapAchieveBundleResourceTmp
        {
            get
            {
                if (string.IsNullOrEmpty(_tapAchieveBundleResourceTmp))
                {
                    _tapAchieveBundleResourceTmp = $"{XcodeProjDir}TapAchievementResource";
                }
                return _tapAchieveBundleResourceTmp;
            }
        }
        
        
        private string _tapAchieveBundleSrc;
        public string TapAchieveBundleSrc
        {
            get
            {
                if (string.IsNullOrEmpty(_tapAchieveBundleSrc))
                {
                    _tapAchieveBundleSrc = $"{XcodeProjDir}Frameworks/TapTap/Achievement/Plugins/iOS/Resource/TapAchievementResource.bundle";
                }
                
                return _tapAchieveBundleSrc;
            }
        }
        
        
        private string _tapAchieveBundleDst;
        public string TapAchieveBundleDst
        {
            get
            {
                if (string.IsNullOrEmpty(_tapAchieveBundleDst))
                {
                    _tapAchieveBundleDst = $"{XcodeProjDir}TapAchievementResource.bundle";
                }
                
                return _tapAchieveBundleDst;
            }
        }
        public ProcessIOSPbxFileStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();

            try
            {
                
                var result = GSQBuildMgr.SendBuildProgress(StepContent);
                
                File.Copy(XcodeConfigAppController, XcodeAppController, true);
                File.Copy(MangoPropertiesConfig, MangoProperties, true);
                File.Copy(InfoPlistConfig, InfoPlist, true);
                
                //taptap resourcebundle
                /*GSQBuildMgr.CopyDirectory(TapBillboardBundleSrc, TapBillboardBundleDst);
                GSQBuildMgr.CopyDirectory(TapCommonBundleSrc, TapCommonBundleDst);
                GSQBuildMgr.CopyDirectory(TapMomentBundleSrc, TapMomentBundleDst);
                GSQBuildMgr.CopyDirectory(TapAchieveBundleSrc, TapAchieveBundleDst);
                
                GSQBuildMgr.DeleteDirectory(TapBillboardBundleResourceTmp);
                GSQBuildMgr.DeleteDirectory(TapCommonBundleResourceTmp);
                GSQBuildMgr.DeleteDirectory(TapMomentBundleResourceTmp);
                GSQBuildMgr.DeleteDirectory(TapAchieveBundleResourceTmp);*/

                PBXProject newPbxProj = new PBXProject();
                newPbxProj.ReadFromFile(XcodeUnityIphoneProj);
                
                string mainTargetGuid = newPbxProj.GetUnityMainTargetGuid();
                string unityFrameworkTarget = newPbxProj.GetUnityFrameworkTargetGuid();
                
                var projectGuid = newPbxProj.ProjectGuid();
                //GSQBuildMgr.AppendLog("projectGuid==>" + projectGuid);
                
                newPbxProj.SetBuildProperty(mainTargetGuid, "CURRENT_PROJECT_VERSION", AppVersion);
                newPbxProj.SetBuildProperty(mainTargetGuid, "MARKETING_VERSION", GenVersionInfo);
                
                newPbxProj.SetBuildProperty(unityFrameworkTarget, "CURRENT_PROJECT_VERSION", AppVersion);
                newPbxProj.SetBuildProperty(unityFrameworkTarget, "MARKETING_VERSION", GenVersionInfo);
                
                newPbxProj.SetBuildProperty(mainTargetGuid, "ALWAYS_EMBED_SWIFT_STANDARD_LIBRARIES", "YES");
                newPbxProj.SetBuildProperty(unityFrameworkTarget, "ALWAYS_EMBED_SWIFT_STANDARD_LIBRARIES", "NO");

                var token = newPbxProj.GetBuildPropertyForAnyConfig(mainTargetGuid, "USYM_UPLOAD_AUTH_TOKEN");
                if (string.IsNullOrEmpty(token))
                {
                    token = "GSQToken";
                }

                string GSQ_GUID = "ARP7HBHFLD";

                newPbxProj.SetBuildProperty(mainTargetGuid, "USYM_UPLOAD_AUTH_TOKEN", token);
                newPbxProj.SetBuildProperty(unityFrameworkTarget, "USYM_UPLOAD_AUTH_TOKEN", token);
                newPbxProj.SetBuildProperty(projectGuid, "USYM_UPLOAD_AUTH_TOKEN", token);
                
                newPbxProj.SetBuildProperty(mainTargetGuid, "ENABLE_BITCODE", "NO");
                newPbxProj.SetBuildProperty(unityFrameworkTarget, "ENABLE_BITCODE", "NO");
                
                newPbxProj.SetBuildProperty(mainTargetGuid, "GCC_ENABLE_OBJC_EXCEPTIONS", "YES");
                newPbxProj.SetBuildProperty(unityFrameworkTarget, "GCC_ENABLE_OBJC_EXCEPTIONS", "YES");
                
                newPbxProj.SetBuildProperty(mainTargetGuid, "OTHER_LDFLAGS", "-ObjC -lc++");
                newPbxProj.SetBuildProperty(unityFrameworkTarget, "OTHER_LDFLAGS", "-ObjC -lc++");
                
                newPbxProj.SetBuildProperty(mainTargetGuid, "ONLY_ACTIVE_ARCH", "NO");
                newPbxProj.SetBuildProperty(unityFrameworkTarget, "ONLY_ACTIVE_ARCH", "NO");

                newPbxProj.SetBuildProperty(mainTargetGuid, "TARGETED_DEVICE_FAMILY", "1,2");
                newPbxProj.SetBuildProperty(unityFrameworkTarget, "TARGETED_DEVICE_FAMILY", "1,2");
            
                
                //添加依赖-
                //添加Frameworks
                newPbxProj.AddFrameworkToProject(unityFrameworkTarget, "libz.tbd", false);
                newPbxProj.AddFrameworkToProject(unityFrameworkTarget, "libc++.tbd", false);
                newPbxProj.AddFrameworkToProject(unityFrameworkTarget, "libsqlite3.0.tbd", false);
                newPbxProj.AddFrameworkToProject(unityFrameworkTarget, "libresolv.tbd", false);
                
                //mango
                string mangoKitGuid = newPbxProj.AddFile(MangoSdkFramework, "Frameworks/MangoKit.framework", PBXSourceTree.Sdk);
                //添加Embedded Content
                newPbxProj.AddFileToEmbedFrameworks(mainTargetGuid, mangoKitGuid);
                
                string reYunSkdGuid = newPbxProj.AddFile(ReYunFramework, "Frameworks/ReYunFramework.framework", PBXSourceTree.Sdk);
                newPbxProj.AddFileToEmbedFrameworks(mainTargetGuid, reYunSkdGuid);
                
                //添加Copy Bundle Resources
                string mangoPropGuid = newPbxProj.AddFile(MangoProperties, "mango.properties", PBXSourceTree.Source);
                newPbxProj.AddFileToBuild(mainTargetGuid, mangoPropGuid);

                string mangoBundleGuid = newPbxProj.AddFile(MangoBundle, "MangoBundle.bundle", PBXSourceTree.Source);
                newPbxProj.AddFileToBuild(mainTargetGuid, mangoBundleGuid);
                
                string weiboBundleGuid = newPbxProj.AddFile(WeiboSDKBundle, "WeiboSDK.bundle", PBXSourceTree.Source);
                newPbxProj.AddFileToBuild(mainTargetGuid, weiboBundleGuid);

                //修改完成
                newPbxProj.WriteToFile(XcodeUnityIphoneProj);
                
                //添加权限
                UpdateXcodeInfoPlistFile();
                

                KLog.Dbg2(this, "iOS XCode工程配置修改完成  SUCCESS！");
                GSQBuildMgr.AppendLog("iOS XCode工程配置修改完成 SUCCESS！");

                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }

        private void UpdateXcodeInfoPlistFile()
        {
            //添加权限
            string plistFile = XcodeProjDir + "/Info.plist";

            PlistDocument plistDoc = new PlistDocument();
            plistDoc.ReadFromString(File.ReadAllText(plistFile));
            PlistElementDict plistEleDic = plistDoc.root;

            /*plistEleDic.SetString("NSPhotoLibraryUsageDescription", "获取用户手机相册用于提供相册图片素材");
            plistEleDic.SetString("NSPhotoLibraryAddUsageDescription", "将图片保存到手机相册");

            //添加权限-
            plistEleDic.SetString("NSUserTrackingUsageDescription", "为了为您更精准地推荐个性化内容，申请获取您的广告标识符");
            plistEleDic.SetString("TrackingUsageDescription", "该标识符将用于标识设备并保障服务安全");
            plistEleDic.SetBoolean("ITSAppUsesNonExemptEncryption", false);*/
            
            //修改版本号信息
            plistEleDic.SetString("CFBundleShortVersionString", AppVersion);
            plistEleDic.SetString("CFBundleVersion", GenVersionInfo);
            var localizationsArray = plistEleDic.CreateArray("CFBundleLocalizations");
            if (IsEnglish)
            {
                localizationsArray.AddString("en"); // 添加英文
            }
            else
            {
                localizationsArray.AddString("zh-Hans"); // 添加简体中文
            }
            
            //plistEleDic.SetString("UIUserInterfaceStyle", "Dark");

            File.WriteAllText(plistFile, plistDoc.WriteToString());
        }

        public override void OnEnd()
        {
            base.OnEnd();
        }


        private float _progress = 0.0f;

        public override float Progress => _progress;
    }
}

#endif