using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using XiaWorld;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessSettingAndScriptStep : GSQBuildStep
    {
        
        private float _progress = 0.0f;
        public override float Progress => _progress;

        public ProcessSettingAndScriptStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }


        public override void OnStart()
        {
            base.OnStart();

            try
            {
                var result = GSQBuildMgr.SendBuildProgress(StepContent);
                var isSettingSuccess = GSQBuildMgr.OnProcessSettingAndScripts();
                if (!isSettingSuccess)
                {
                    SetResult(BuildResult.Failed, "OnProcessSettingAndScripts failed!");
                    GSQBuildMgr.AppendLog("OnProcessSettingAndScripts failed!");
                }
                
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }
       
        

        public override void OnEnd()
        {
            //TODO
            base.OnEnd();
        }
    }
}