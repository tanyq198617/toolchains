using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using XiaWorld;
using xasset.editor;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessPlayerSettingStep : GSQBuildStep
    {

        private string _androidManifestPath = "Assets/Plugins/Android/AndroidManifest.xml";
        public ProcessPlayerSettingStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();

            try
            {
                
                var result = GSQBuildMgr.SendBuildProgress(StepContent);
				EditorPrefs.SetInt("CacheServerMode", 2);

                PlayerSettings.productName = IsEnglish ? "Amazing Cultivation Simulator" : "了不起的修仙模拟器";
                SetLogo();
                SetKeyStoreInfo();
#if UNITY_ANDROID
                PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.Android);
                
                PlayerSettings.applicationIdentifier = "com.GSQ.XiaWorld";

                if (!string.IsNullOrEmpty(PackExt))
                {
                    PlayerSettings.applicationIdentifier += PackExt;
                }

                EditorUserBuildSettings.buildAppBundle = GSQBuildMgr.LoginSdkType == SdkType.GooglePlay;

                int.TryParse(GenVersionInfo,out var bundleVersionCode);
                PlayerSettings.Android.bundleVersionCode = bundleVersionCode;
                GSQBuildMgr.AppendLog("GenVersionInfoTime==>" + GenVersionInfo + "  PlayerSettings.Android.bundleVersionCode==>" + PlayerSettings.Android.bundleVersionCode);
                
                EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
                EditorUserBuildSettings.androidCreateSymbolsZip = true;
              
                EditorUserBuildSettings.development = IsDevelop;
                EditorUserBuildSettings.allowDebugging = IsDevelop;
                EditorUserBuildSettings.connectProfiler = IsDevelop;

                PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel25;
                PlayerSettings.Android.targetSdkVersion = (AndroidSdkVersions)34;

                GSQBuildMgr.AppendLog($"PlayerSettings.Android.minSdkVersion==>{PlayerSettings.Android.minSdkVersion} PlayerSettings.Android.targetSdkVersion=>{PlayerSettings.Android.targetSdkVersion }");
                ProcessManifest();
                
                PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android,ScriptBackend);
                PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.Android, ManagedStrippingLevel.Low);
              
                
#elif UNITY_IOS
                PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.iOS);
                PlayerSettings.applicationIdentifier = "com.mangofun.lbqdxxmnq";
                PlayerSettings.iOS.buildNumber = GenVersionInfo;
                PlayerSettings.iOS.appleDeveloperTeamID = "ARP7HBHFLD";
                PlayerSettings.iOS.targetOSVersionString = "11.0";
                // 允许自动旋转
                PlayerSettings.useAnimatedAutorotation = true;
                PlayerSettings.allowedAutorotateToLandscapeLeft = true;
                PlayerSettings.allowedAutorotateToLandscapeRight = true;

                // Debug模式下
    #if DEBUG
                    PlayerSettings.iOS.iOSManualProvisioningProfileID = "8a7a47ba-1d1c-4577-86ba-5b330a0e8a83"; //dev
                    PlayerSettings.iOS.iOSManualProvisioningProfileType = ProvisioningProfileType.Development;
    #else
                    // Release模式下
                    //adhoc mobileprovisionId==> e7648ded-034b-4691-a513-86047de3f68f
                    if (EnableProduct)
                    {
                        PlayerSettings.iOS.iOSManualProvisioningProfileID = "ce539571-5368-477f-a663-23b6111c8b81"; //正式发布 dis
                    }
                    else
                    {
                        PlayerSettings.iOS.iOSManualProvisioningProfileID = "e7648ded-034b-4691-a513-86047de3f68f"; //adhoc
                    }
                    PlayerSettings.iOS.iOSManualProvisioningProfileID = "e7648ded-034b-4691-a513-86047de3f68f"; //adhoc
                    PlayerSettings.iOS.iOSManualProvisioningProfileType = ProvisioningProfileType.Distribution;
    #endif
                PlayerSettings.SetScriptingBackend(BuildTargetGroup.iOS, ScriptBackend);
                PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.iOS, ManagedStrippingLevel.Low);

                // 获取当前设置的Splash Screen logos
                List<PlayerSettings.SplashScreenLogo> splashLogosList = new List<PlayerSettings.SplashScreenLogo>(PlayerSettings.SplashScreen.logos);
                // 创建新的logo设置
                PlayerSettings.SplashScreenLogo newSplashLogo = new PlayerSettings.SplashScreenLogo();
                // 假设有一个名为"NewSplashLogo"的Sprite在你的资源文件夹中
                newSplashLogo.logo = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/Res/logo/mango_fusion_splash_blackbg.png");
                // 设置展示时间
                newSplashLogo.duration = 2.0f;
                // 将新的logo添加到列表中
                splashLogosList.Add(newSplashLogo);
                // 将列表转换回数组并应用到PlayerSettings
                PlayerSettings.SplashScreen.logos = splashLogosList.ToArray();
                PlayerSettings.SplashScreen.backgroundColor = Color.black;

#endif
                
                PlayerSettings.stripEngineCode = false;
                
				SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }
        private void SetLogo()
        {
            if (!IsEnglish)
            {
                PlayerSettings.SplashScreen.logos = new PlayerSettings.SplashScreenLogo[]
                {
                    new PlayerSettings.SplashScreenLogo()
                        { logo = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/Res/logo/gg.jpg"), duration = 5f },
                    new PlayerSettings.SplashScreenLogo()
                        { logo = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/Res/logo/GSQlogo.png"), duration = 2f }
                };
            }
            else
            {
                PlayerSettings.SplashScreen.logos = new PlayerSettings.SplashScreenLogo[]
                {
                    new PlayerSettings.SplashScreenLogo()
                        { logo = AssetDatabase.LoadAssetAtPath<Sprite>("Assets/Res/logo/GSQlogo.png"), duration = 2f }
                };
            }
        }


        private void ProcessManifest()
        {
            string suffix;
            switch (LoginSdkType)
            {
                case SdkType.Bili:
                    suffix = ".bili";
                    break;
                case SdkType.Mango:
                    suffix = ".mango";
                    break;
                case SdkType.GooglePlay:
                    suffix = ".googleplay";
                    break;
                default:
                    suffix = ".normal";
                    break;
            }
            string manifestPath = GFileUtil.LocateFile(_androidManifestPath);
            if (File.Exists(manifestPath))
            {
                File.Delete(manifestPath);
            }
            string filepath = manifestPath + suffix;
            File.Copy(filepath, manifestPath);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }
        
        private void SetKeyStoreInfo()
        {
            var keystoreName = string.Empty;
            var keystorpass = string.Empty;
            var keyaliasName = string.Empty;
            var keyaliasPass = string.Empty;
            switch (LoginSdkType)
            {
                case SdkType.GooglePlay:
                    keystoreName = "xiaworld.keystore";
                    keystorpass = "123456";
                    keyaliasName = "xiaworld.keystore";
                    keyaliasPass = "123456";
                    break;
                default:
                    keystoreName = "user.keystore";
                    keystorpass = "gsq123gsq!";
                    keyaliasName = "xiaworld";
                    keyaliasPass = "wKt8DVFPlWNepE5";
                    break;
            }
            //秘钥名称：注意这里要加上.keystore后缀
            PlayerSettings.Android.keystoreName = keystoreName;
            // 密钥密码
            PlayerSettings.Android.keystorePass = keystorpass;
            // 密钥别名
            PlayerSettings.Android.keyaliasName = keyaliasName;
            // 密钥别名密码
            PlayerSettings.Android.keyaliasPass = keyaliasPass;
        }

        public override void OnEnd()
        {
            base.OnEnd();
        }


        private float _progress = 0.0f;

        public override float Progress => _progress;
    }
}