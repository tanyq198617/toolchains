using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using UnityEditor;
using xasset.editor;
using UnityEngine;
using XiaWorld.ClientCore.AsyncOperation;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessBundleUploadStep : GSQBuildStep
    {

        private string _assetUploadPath = "https://acs-user-1253412057.cos.ap-chengdu.myqcloud.com/Assets/";
        private WaitForAsyncOperation _uploadBundleAsync;
        private bool _uploadResult;
        
        public ProcessBundleUploadStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
            
        }
        
        public override void OnStart()
        {
            base.OnStart();
            
            /*try
            {
                _uploadBundleAsync = new WaitForAsyncOperation((object o)=>
                {
                    GSQBuildMgr.UploadBundleByS3cmd();
                    return true;
                }, _uploadResult);

                if (_uploadBundleAsync.Success)
                {
                    SetResult(BuildResult.Success);
                }
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }*/
           //var result = SendBuildProgress();
           SetResult(BuildResult.Success);
        }

        public override void OnEnd()
        {
            //TODO
            base.OnEnd();
        }


        private float _progress = 0.0f;

        public override float Progress => _progress;
    }
}