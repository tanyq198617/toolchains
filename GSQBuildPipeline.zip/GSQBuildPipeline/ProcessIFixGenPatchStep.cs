
using System;
using System.Diagnostics;
using System.IO;
using IFix;
using IFix.Editor;

namespace Code.Editor.GSQBuildPipeline
{ 
    public class ProcessIFixGenPatchStep  : GSQBuildStep
    {
        public ProcessIFixGenPatchStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
            
        }
        
        public override void OnStart()
        {
            base.OnStart();
            var buildProgress = GSQBuildMgr.SendBuildProgress(StepContent);
            try
            {
#if UNITY_ANDROID
                IFixEditor.CompileToAndroid();  
# elif UNITY_IOS
             
                IFixEditor.CompileToIOS();  
#endif
                
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }


        }
        
        public override void OnEnd()
        {
            base.OnEnd();
        }

        
        private float _progress = 0.0f;
        public override float Progress => _progress;

    }
}