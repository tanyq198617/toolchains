using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using XiaWorld;
using xasset.editor;
using Settings = xasset.editor.Settings;
using System.Diagnostics;
using System.Threading;
using IFix.Editor;
using xasset.pad.editor;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessApksFromAppBundleStep : GSQBuildStep
    {
        public ProcessApksFromAppBundleStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }
        
        public override void OnStart()
        {
            base.OnStart();

            try
            {
                var sendProgress = GSQBuildMgr.SendBuildProgress(StepContent);
                var appBundlePath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.aab".Replace('\\', '/');
                var apksPath = $"{Environment.CurrentDirectory}/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.apks".Replace('\\', '/');
                var toolsPath = $"{Environment.CurrentDirectory}/i18n_build_tools/".Replace('\\', '/');
                GSQBuildMgr.AppendLog($"processApksFromAppBundle_appBundlePath=>{appBundlePath} apksPath=>{apksPath} toolsPath=>{toolsPath}");
                
                while (!File.Exists(appBundlePath))
                {
                    Thread.Sleep(1000);
                }
                if(File.Exists(appBundlePath))
                {
                    string batCmd = $"BuildI18NApksFromAppBundle.bat \"{appBundlePath}\" \"{apksPath}\" \"{toolsPath}\"";
                    GSQBuildMgr.AppendLog($"batCommand=>{batCmd}");
                    var isSuccess = GSQBuildMgr.ExecuteBatCommand(batCmd, toolsPath);
                    if (isSuccess)
                    {
                        var successMsg = $"<font color=\"warning\">Great,从app bundle文件导出APKS文件成功! 但需要注意APKS文件并非能直接安装的文件，需要使用InstallI18NApks.bat批处理文件安装!</font>\n";
                        sendProgress = GSQBuildMgr.SendBuildProgress(successMsg);
                        GSQBuildMgr.AppendLog(successMsg);
                        SetResult(BuildResult.Success);
                    }
                    else
                    {
                        var failMsg = $"<font color=\"error\">Sorry,从app bundle导出APKS文件失败!</font>\n";
                        sendProgress = GSQBuildMgr.SendBuildProgress(failMsg);
                        SetResult(BuildResult.Failed,failMsg);
                    }
                }

            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed,e.Message);
                throw;
            }
           
        }

        public override void OnEnd()
        {
            base.OnEnd();
        }


        private float _progress = 0.0f;

        public override float Progress => _progress;
    }
}