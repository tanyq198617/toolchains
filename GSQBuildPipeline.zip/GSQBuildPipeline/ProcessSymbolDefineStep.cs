using System;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using XiaWorld;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessSymbolDefineStep : GSQBuildStep
    {
        public ProcessSymbolDefineStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public override void OnStart()
        {
            base.OnStart();

            try
            {
                
                string curDf = string.Empty;
#if UNITY_ANDROID
                curDf = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.Android);
#elif UNITY_IOS
                curDf = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.iOS);
#endif
                GSQBuildMgr.AppendLog("scripting define symbols_before==>" + curDf);

                AddSymbolDefine("USE_SDK;", LoginSdkType > 0, ref curDf);
                AddSymbolDefine("MANGO_ENABLE;", LoginSdkType == SdkType.Mango, ref curDf);
                AddSymbolDefine("GOOGLE_PLAY_ENABLE;", LoginSdkType == SdkType.GooglePlay, ref curDf);
                AddSymbolDefine("IOS_GAME_CENTER_ENABLE;",LoginSdkType == SdkType.iOSGameCenter, ref curDf);
                AddSymbolDefine("DEV_LOADING;", DevLoading, ref curDf);
                AddSymbolDefine("USE_UWA;", UseUWA, ref curDf);
                //强制开启热更,否则热更文件无法进包
				AddSymbolDefine("HOTFIX_ENABLE;", true, ref curDf);
                AddSymbolDefine("EnableProduct;", EnableProduct, ref curDf);
                AddSymbolDefine("CHANNEL;", IsChannel, ref curDf);

#if UNITY_ANDROID

                PlayerSettings.SetScriptingDefineSymbolsForGroup(BuildTargetGroup.Android, curDf);
                PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel22;
                switch (LoginSdkType)
                {
                    case SdkType.GooglePlay:
                        PlayerSettings.Android.targetSdkVersion = (AndroidSdkVersions)33;
                        break;
                    default:
                        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel30;
                        break;
                }
                
                ChangeBSDK();

#elif UNITY_IOS
                PlayerSettings.SetScriptingDefineSymbolsForGroup(BuildTargetGroup.iOS, curDf);
#endif
                
                
                AssetDatabase.Refresh();
#if UNITY_ANDROID
                curDf = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.Android);
#elif UNITY_IOS
                curDf = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.iOS);
                
#endif
                GSQBuildMgr.AppendLog("scripting define symbols_after==>" + curDf);
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }

        public void ChangeBSDK()
        {
            string androidPluginPath = "Assets/Plugins/Android/";
            switch (LoginSdkType)
            {
                case SdkType.Bili:
                    for (int i = 0; i < CoreMangoJars.Length; i++)
                    {
                        string path = androidPluginPath + CoreMangoJars[i];
                        WriteAndroidEnable(path, false);
                    }
                    
                    for (int i = 0; i < GooglePlayJars.Length; i++)
                    {
                        string path = androidPluginPath + GooglePlayJars[i];
                        WriteAndroidEnable(path, false);
                    }

                    for (int i = 0; i < NormalJars.Length; i++)
                    {
                        string path = androidPluginPath + NormalJars[i];
                        WriteAndroidEnable(path, true);
                    }

                    break;
                case SdkType.Mango:
                    for (int i = 0; i < NormalJars.Length; i++)
                    {
                        string path = androidPluginPath + NormalJars[i];
                        WriteAndroidEnable(path, false);
                    }

                    for (int i = 0; i < GooglePlayJars.Length; i++)
                    {
                        string path = androidPluginPath + GooglePlayJars[i];
                        WriteAndroidEnable(path, false);
                    }
                    
                    for (int i = 0; i < CoreMangoJars.Length; i++)
                    {
                        string path = androidPluginPath + CoreMangoJars[i];
                        WriteAndroidEnable(path, true);
                    }

                    break;
                case SdkType.GooglePlay:
                    for (int i = 0; i < NormalJars.Length; i++)
                    {
                        string path = androidPluginPath + NormalJars[i];
                        WriteAndroidEnable(path, false);
                    }

                    for (int i = 0; i < CoreMangoJars.Length; i++)
                    {
                        string path = androidPluginPath + CoreMangoJars[i];
                        WriteAndroidEnable(path, false);
                    }
                    
                    for (int i = 0; i < GooglePlayJars.Length; i++)
                    {
                        string path = androidPluginPath + GooglePlayJars[i];
                        WriteAndroidEnable(path, true);
                    }
                    
                    break;
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        public void WriteAndroidEnable(string filepath, bool enable)
        {
            var ipt = AssetImporter.GetAtPath(filepath) as PluginImporter;
            if (ipt == null) return;
            ipt.SetCompatibleWithPlatform(BuildTarget.Android, enable);
            EditorUtility.SetDirty(ipt);
        }


        public void AddSymbolDefine(string v, bool add, ref string rs)
        {
            if (string.IsNullOrEmpty(rs))
            {
                return;
            }
            rs = rs.Replace(v, "");
            rs = rs.Replace(v.Replace(";", ""), "");
            if (add)
            {
                if (rs[rs.Length - 1] == ';')
                    rs += v;
                else
                    rs += ";" + v;
            }
        }


        public override void OnEnd()
        {
            base.OnEnd();
        }


        private float _progress = 0.0f;
        public override float Progress => _progress;

    }
}