using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json;
using UnityEditor;
using UnityEngine;
using xasset.editor;
using XiaWorld;

using HttpClient = System.Net.Http.HttpClient;


namespace Code.Editor.GSQBuildPipeline
{
    
    public partial class GSQBuildMgr
    {

        private static GSQBuildPipeline _buildPipeline;
        public static GSQBuildPipeline BuildPipeline => _buildPipeline;

        private static string _buildLogPath;

        public static string BuildLogPath
        {
            get
            {
                if (string.IsNullOrEmpty(_buildLogPath))
                {
                    _buildLogPath =
                        $"{Environment.CurrentDirectory}/Build/{Settings.Platform}/custom_build.log".Replace('\\', '/');
                }

                return _buildLogPath;
            }
        }
        
        public const string platform_Bili = "Bili";
        public const string platform_Mango = "Mango";
        public const string platform_GooglePlay = "GooglePlay";
        public const string platform_iOSGameCenter = "iOSGameCenter";

        public static bool IsBuilding => _buildPipeline != null && (_buildPipeline != null || !_buildPipeline.IsDone);

        private static string webhookUrl = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=c50936bf-5448-4598-94b6-1d550e0906cb";
        
        private static string _aabFilePath = $"D:/XiaWorld_Android_i18n/XiaWorld/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.aab";
        public static string AAbFilePath => _aabFilePath;

        private static string _apksFilePath = $"D:/XiaWorld_Android_i18n/XiaWorld/Build/Android/{PlayerSettings.productName}_{PlayerSettings.bundleVersion}_{PlayerSettings.Android.bundleVersionCode}.apks";
        public static string ApksFilePath => _apksFilePath;
        
        private static HttpClient _client;
        private static SdkType _loginSdkType = SdkType.GooglePlay;
        public static SdkType LoginSdkType => _loginSdkType;
        public static string SdkTypeStr
        {
            get
            {
                var sdkTypeStr = "Mango";
                switch (LoginSdkType)
                {
                    case SdkType.Bili:
#if UNITY_ANDROID
                        sdkTypeStr = "Bili Android";         

#elif UNITY_IOS
                        sdkTypeStr = "Bili iOS";
#endif
                        break;
                    case SdkType.Mango:
#if UNITY_ANDROID
                        sdkTypeStr = "Mango Android";         

#elif UNITY_IOS
                        sdkTypeStr = "Mango iOS";
#endif
                        break;
                    case SdkType.GooglePlay:
                        sdkTypeStr = "GooglePlay";
                        break;
                    case SdkType.iOSGameCenter:
                        sdkTypeStr = "iOSGameCenter";
                        break;
                }

                return sdkTypeStr;
            }
        }

        private static bool _isOnlyObjectCOrSdkChanged = false;
        
        private static bool _isOnlyBuildPlayer = true;
        
        private static bool _isSendBuildProgress = false;



        public static void ExecuteBuild()
        {
            DestroyBuildPipeline();
            PurgeLogFile();
            if (_isSendBuildProgress)
            {
                var args = Environment.GetCommandLineArgs();
                var opts = CommandLine.ParseOpt(args);
                if (opts.Count > 0)
                {
                    var onlyBuildPlayerArg = opts.Find(v => v.Opt == "onlyBuildPlayer")?.Arg;
                    bool.TryParse(onlyBuildPlayerArg, out _isOnlyBuildPlayer);
#if UNITY_IOS
                    var isOnlyObjectCOrSdkChangedArg = opts.Find(v => v.Opt == "isOnlyObjectCOrSdkChanged")?.Arg;
                    Boolean.TryParse(isOnlyObjectCOrSdkChangedArg, out _isOnlyObjectCOrSdkChanged);
                    if (_isOnlyObjectCOrSdkChanged)
                    {
                        _isOnlyBuildPlayer = _isOnlyObjectCOrSdkChanged;
                    }
                    AppendLog("isOnlyObjectCOrSdkChanged==>" + isOnlyObjectCOrSdkChangedArg);
#endif
                   
                    var platformInfo = opts.Find(v => v.Opt == "platformName")?.Arg;
                    AppendLog("platformName==>" + platformInfo);
                    
                    switch (platformInfo)
                    {
                        case platform_Bili:
                            _loginSdkType = SdkType.Bili;
                            break;
                        case platform_Mango:
                            _loginSdkType = SdkType.Mango;
                            break;
                        case platform_GooglePlay:
                            _loginSdkType = SdkType.GooglePlay;
                            break;
                        case platform_iOSGameCenter:
                            _loginSdkType = SdkType.iOSGameCenter;
                            break;
                    }

                }
            }

            _buildPipeline = CreateBuildPipeline();
            _buildPipeline.FinishCallback += OnBuildFinished;
            _buildPipeline.Start();
            _buildPipeline.Run();
        }

        private static GSQBuildPipeline CreateBuildPipeline()
        {

#if UNITY_ANDROID
            return CreateAndroidBuildPipeline();
#elif UNITY_IOS
            return CreateIOSBuildPipeline();
#endif

        }

#if UNITY_ANDROID
        private static GSQBuildPipeline CreateAndroidBuildPipeline()
        {
            int step = 1;
            var buildPipeline = new GSQBuildPipeline();
            if (_isOnlyBuildPlayer)
            {
                var contentStr = $"<font color=\"info\">#{SdkTypeStr} 版本构建步骤提示</font><font color=\"warning\">本次构建已经跳过了资产预处理，bundle构建等耗时步骤，将节省不少构建时间，开发期间只修改代码时使用!</font>\n";
                var result = SendBuildProgress(contentStr);

                var jenkinParamStep =
                    buildPipeline.RegisterStep(new ProcessJenkinParamStep(step++, "ProcessJenkinParamStep")) as
                        ProcessJenkinParamStep;
                var symbolDefineStep =
                    buildPipeline.RegisterStep(new ProcessSymbolDefineStep(step++, "ProcessSymbolDefineStep")) as
                        ProcessSymbolDefineStep;

                var playerSettingStep =
                    buildPipeline.RegisterStep(new ProcessPlayerSettingStep(step++, "ProcessPlayerSettingStep")) as
                        ProcessPlayerSettingStep;

                var iFixInjectStep = buildPipeline.RegisterStep(new ProcessIFixInjectStep(step++, "ProcessIFixInjectStep")) as ProcessIFixInjectStep;

                switch (LoginSdkType)
                {
                    case SdkType.GooglePlay: 
                    
                        var appBundleStep = buildPipeline.RegisterStep(new ProcessAppBundleStep(step++, "ProcessAppBundleStep")) as ProcessAppBundleStep;
                        var appBundleSignStep = buildPipeline.RegisterStep(new ProcessAppBundleSignStep(step++, "ProcessAppBundleSignStep")) as ProcessAppBundleSignStep;
                        var processApksStep = buildPipeline.RegisterStep(new ProcessApksFromAppBundleStep(step++, "ProcessApksFromAppBundleStep")) as
                            ProcessApksFromAppBundleStep;
                           
                        var sendResultStep =
                            buildPipeline.RegisterStep(new ProcessSendBuildResultStep(step++, "ProcessSendBuildResultStep")) as
                                ProcessSendBuildResultStep;
                        sendResultStep?.AddDependency(appBundleStep,appBundleSignStep,processApksStep);
                        break;
                    default:
                        var playerStep =
                            buildPipeline.RegisterStep(new ProcessPlayerBuildStep(step++, "ProcessPlayerBuildStep")) as
                                ProcessPlayerBuildStep;
                        playerStep?.AddDependency(symbolDefineStep,playerSettingStep,iFixInjectStep);
                        sendResultStep =
                            buildPipeline.RegisterStep(new ProcessSendBuildResultStep(step++, "ProcessSendBuildResultStep")) as
                                ProcessSendBuildResultStep;
                        sendResultStep?.AddDependency(playerStep);
                        break;
                }
               
        
            }
            else
            {
                var contentStr = $"<font color=\"info\">#{SdkTypeStr} 版本构建步骤提示</font><font color=\"warning\">本次构建是全量构建，包括游戏资产预处理，bundle构建等操作!</font>\n";
                //var contentStr = $"<font color=\"info\">#海外版{SdkTypeStr} 出包流程调整本地调试，请忽略!</font>\n";
                var result = SendBuildProgress(contentStr);

                var jenkinParamStep =
                    buildPipeline.RegisterStep(new ProcessJenkinParamStep(step++, "ProcessJenkinParamStep")) as
                        ProcessJenkinParamStep;
                var languageStep =
                    buildPipeline.RegisterStep(new ProcessLanguageStep(step++, "ProcessLanguageStep")) as
                        ProcessLanguageStep;
                var settingAndScriptStep =
                    buildPipeline.RegisterStep(new ProcessSettingAndScriptStep(step++, "ProcessSettingAndScriptStep"))
                        as ProcessSettingAndScriptStep;
                var teachFileStep =
                    buildPipeline.RegisterStep(new ProcessTeachFileStep(step++, "ProcessTeachFileStep"))
                        as ProcessTeachFileStep;
                var buildBundleStep =
                    buildPipeline.RegisterStep(new ProcessBundleBuildStep(step++, "ProcessBuildBundleStep")) as
                        ProcessBundleBuildStep;
                buildBundleStep?.AddDependency(languageStep, settingAndScriptStep, teachFileStep);

                var updateInfoFileStep =
                    buildPipeline.RegisterStep(new ProcessUpdateInfoFileStep(step++, "ProcessUpdateInfoFileStep")) as
                        ProcessUpdateInfoFileStep;
                updateInfoFileStep?.AddDependency(buildBundleStep);

                var uploadAssetBundleStep =
                    buildPipeline.RegisterStep(new ProcessBundleUploadStep(step++, "ProcessUploadAssetBundleStep")) as
                        ProcessBundleUploadStep;
                uploadAssetBundleStep?.AddDependency(buildBundleStep, updateInfoFileStep);

                var symbolDefineStep =
                    buildPipeline.RegisterStep(new ProcessSymbolDefineStep(step++, "ProcessSymbolDefineStep")) as
                        ProcessSymbolDefineStep;
                var playerSettingStep =
                    buildPipeline.RegisterStep(new ProcessPlayerSettingStep(step++, "ProcessPlayerSettingStep")) as
                        ProcessPlayerSettingStep;

                var iFixInjectStep = buildPipeline.RegisterStep(new ProcessIFixInjectStep(step++, "ProcessIFixInjectStep")) as ProcessIFixInjectStep;
                
                switch (LoginSdkType)
                {
                    case SdkType.GooglePlay: 
                        var appBundleStep = buildPipeline.RegisterStep(new ProcessAppBundleStep(step++, "ProcessAppBundleStep")) as ProcessAppBundleStep;
                        var appBundleSignStep = buildPipeline.RegisterStep(new ProcessAppBundleSignStep(step++, "ProcessAppBundleSignStep")) as ProcessAppBundleSignStep;
                        var processApksStep = buildPipeline.RegisterStep(new ProcessApksFromAppBundleStep(step++, "ProcessApksFromAppBundleStep")) as
                            ProcessApksFromAppBundleStep;
                           
                        var sendResultStep =
                            buildPipeline.RegisterStep(new ProcessSendBuildResultStep(step++, "ProcessSendBuildResultStep")) as
                                ProcessSendBuildResultStep;
                        sendResultStep?.AddDependency(appBundleStep,appBundleSignStep,processApksStep);
                        break;
                    default:
                        var playerStep =
                            buildPipeline.RegisterStep(new ProcessPlayerBuildStep(step++, "ProcessPlayerBuildStep")) as
                                ProcessPlayerBuildStep;
                        playerStep?.AddDependency(symbolDefineStep,playerSettingStep,iFixInjectStep);
                        sendResultStep =
                            buildPipeline.RegisterStep(new ProcessSendBuildResultStep(step++, "ProcessSendBuildResultStep")) as
                                ProcessSendBuildResultStep;
                        sendResultStep?.AddDependency(playerStep);
                        break;
                }

            }

            return buildPipeline;
        }

#endif

#if UNITY_IOS
        public static GSQBuildPipeline CreateIOSBuildPipeline()
        {

            
            int step = 1;
            var buildPipeline = new GSQBuildPipeline();
            
            if (_isOnlyBuildPlayer)
            {
               
                if (!_isOnlyObjectCOrSdkChanged)
                {
                    var contentStr =
 $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">本次构建已经跳过了资产预处理，bundle构建等耗时步骤，将节省不少构建时间，开发期间只修改了C#代码时使用!</font>\n";
                    var result = SendBuildProgress(contentStr);
                    var jenkinParamStep =
 buildPipeline.RegisterStep(new ProcessJenkinParamStep(step++, "ProcessJenkinParamStep")) as ProcessJenkinParamStep;

                    var symbolDefineStep =
 buildPipeline.RegisterStep(new ProcessSymbolDefineStep(step++, "ProcessSymbolDefineStep")) as ProcessSymbolDefineStep;
                    
                    var playerSettingStep =
 buildPipeline.RegisterStep(new ProcessPlayerSettingStep(step++, "ProcessPlayerSettingStep")) as ProcessPlayerSettingStep;
                    var iFixInjectStep =
 buildPipeline.RegisterStep(new ProcessIFixInjectStep(step++, "ProcessIFixInjectStep")) as ProcessIFixInjectStep;

                    var playerStep =
 buildPipeline.RegisterStep(new ProcessPlayerBuildStep(step++, "ProcessPlayerBuildStep")) as ProcessPlayerBuildStep;
                    playerStep?.AddDependency(symbolDefineStep,playerSettingStep,iFixInjectStep);
                    
                    var iOsPbxFileStep =
 buildPipeline.RegisterStep(new ProcessIOSPbxFileStep(step++, "ProcessIOSPbxFileStep")) as ProcessIOSPbxFileStep;
                    iOsPbxFileStep?.AddDependency(playerStep);
                    
                     var iOsArchiveAndIpaStep =
 buildPipeline.RegisterStep(new ProcessIOSArchiveAndIpaStep(step++, "ProcessIOSArchiveAndIpaStep")) as ProcessIOSArchiveAndIpaStep;
                     iOsArchiveAndIpaStep?.AddDependency(iOsPbxFileStep);
                    
                    var sendResultStep =
 buildPipeline.RegisterStep(new ProcessSendBuildResultStep(step++, "ProcessSendBuildResultStep")) as ProcessSendBuildResultStep;
                    sendResultStep?.AddDependency(iOsArchiveAndIpaStep);
                }
                else
                {
                    var contentStr =
 $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">本次构建已经跳过了所有耗时步聚，当只有Object-C代码改动或者iOS相关sdk替换操作时启用，这样会节省大量构建时间，当且仅当开发期间使用!</font>\n";
                    var result = SendBuildProgress(contentStr);
                    
                    var jenkinParamStep =
 buildPipeline.RegisterStep(new ProcessJenkinParamStep(step++, "ProcessJenkinParamStep")) as ProcessJenkinParamStep;
                  
                    
                    var iOsPbxFileStep =
 buildPipeline.RegisterStep(new ProcessIOSPbxFileStep(step++, "ProcessIOSPbxFileStep")) as ProcessIOSPbxFileStep;
                    var iOsArchiveAndIpaStep =
 buildPipeline.RegisterStep(new ProcessIOSArchiveAndIpaStep(step++, "ProcessIOSArchiveAndIpaStep")) as ProcessIOSArchiveAndIpaStep;
                    iOsArchiveAndIpaStep?.AddDependency(iOsPbxFileStep);
                    var sendResultStep =
 buildPipeline.RegisterStep(new ProcessSendBuildResultStep(step++, "ProcessSendBuildResultStep")) as ProcessSendBuildResultStep;
                    sendResultStep?.AddDependency(iOsArchiveAndIpaStep);
                }
                
            }
            else
            {
                var contentStr =
 $"<font color=\"info\">#iOS 版本构建步骤提示</font><font color=\"warning\">本次构建是全量构建，包括游戏资产预处理，bundle构建等操作!</font>\n";
                var result = SendBuildProgress(contentStr);
                
                var jenkinParamStep =
 buildPipeline.RegisterStep(new ProcessJenkinParamStep(step++, "ProcessJenkinParamStep")) as ProcessJenkinParamStep;
               
                var languageStep =
 buildPipeline.RegisterStep(new ProcessLanguageStep(step++, "ProcessLanguageStep")) as ProcessLanguageStep;
                var settingAndScriptStep =
 buildPipeline.RegisterStep(new ProcessSettingAndScriptStep(step++, "ProcessSettingAndScriptStep")) as ProcessSettingAndScriptStep;
            var teachFileStep =
                    buildPipeline.RegisterStep(new ProcessTeachFileStep(step++, "ProcessTeachFileStep"))
                        as ProcessTeachFileStep;
                var spriteAndTextureLinkStep =
 buildPipeline.RegisterStep(new ProcessSpriteAndTextureLinkStep(step++, "ProcessSpriteAndTextureLinkStep")) as ProcessSpriteAndTextureLinkStep;
                var buildBundleStep =
 buildPipeline.RegisterStep(new ProcessBundleBuildStep(step++, "ProcessBuildBundleStep")) as ProcessBundleBuildStep;
                buildBundleStep?.AddDependency(languageStep, settingAndScriptStep, teachFileStep, spriteAndTextureLinkStep);

                var updateInfoFileStep =
 buildPipeline.RegisterStep(new ProcessUpdateInfoFileStep(step++, "ProcessUpdateInfoFileStep")) as ProcessUpdateInfoFileStep;
                updateInfoFileStep?.AddDependency(buildBundleStep);

                var uploadAssetBundleStep =
 buildPipeline.RegisterStep(new ProcessBundleUploadStep(step++, "ProcessUploadAssetBundleStep")) as ProcessBundleUploadStep;
                uploadAssetBundleStep?.AddDependency(buildBundleStep, updateInfoFileStep);

                var symbolDefineStep =
 buildPipeline.RegisterStep(new ProcessSymbolDefineStep(step++, "ProcessSymbolDefineStep")) as ProcessSymbolDefineStep;
                var playerSettingStep =
 buildPipeline.RegisterStep(new ProcessPlayerSettingStep(step++, "ProcessPlayerSettingStep")) as ProcessPlayerSettingStep;


                var iFixInjectStep =
 buildPipeline.RegisterStep(new ProcessIFixInjectStep(step++, "ProcessIFixInjectStep")) as ProcessIFixInjectStep;
                var playerStep =
 buildPipeline.RegisterStep(new ProcessPlayerBuildStep(step++, "ProcessBuildPlayerStep")) as ProcessPlayerBuildStep;
                playerStep?.AddDependency(symbolDefineStep,playerSettingStep,iFixInjectStep);
                
                var iOsPbxFileStep =
 buildPipeline.RegisterStep(new ProcessIOSPbxFileStep(step++, "ProcessIOSPbxFileStep")) as ProcessIOSPbxFileStep;
                iOsPbxFileStep?.AddDependency(playerStep);
             
                var iOsArchiveAndIpaStep =
 buildPipeline.RegisterStep(new ProcessIOSArchiveAndIpaStep(step++, "ProcessIOSArchiveAndIpaStep")) as ProcessIOSArchiveAndIpaStep;
                iOsArchiveAndIpaStep?.AddDependency(iOsPbxFileStep);

                var sendResultStep =
 buildPipeline.RegisterStep(new ProcessSendBuildResultStep(step++, "ProcessSendBuildResultStep")) as ProcessSendBuildResultStep;
                sendResultStep?.AddDependency(iOsArchiveAndIpaStep);
           

            }

            return buildPipeline;

            
        }

#endif

        private static void OnBuildFinished(bool result)
        {
            AppendLog($"GSQBuildMgr: OnBuildFinished==>{result}");
            var dumpInfo = _buildPipeline?.DumpTimeInfo();
            AppendLog(dumpInfo);
            DestroyBuildPipeline();

        }


        public static void AppendLog(string content)
        {
            if (string.IsNullOrEmpty(content))
            {
                return;
            }

            try
            {
                // 检查文件路径是否存在，如果不存在则创建
                KLog.Dbg(content);
                string directoryPath = Path.GetDirectoryName(BuildLogPath);
                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                if (!File.Exists(BuildLogPath))
                {
                    File.Create(BuildLogPath).Close();
                }

                // 创建或打开文件
                using (StreamWriter sw = new StreamWriter(BuildLogPath, true))
                {
                    // 写入内容
                    sw.WriteLine(content);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("AppendLog__Exception: " + e.Message);
            }
        }


        private static void PurgeLogFile()
        {
            if (File.Exists(BuildLogPath))
            {
                File.Delete(BuildLogPath);
            }
        }

        private static void DestroyBuildPipeline()
        {
            _buildPipeline?.Cancel();
            _buildPipeline = null;

        }

        #region execute cmd op
        public static bool ExecuteCommand(string command)
        {
          
            var processInfo = new ProcessStartInfo("bash", "-c \"" + command + "\"")
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardError = true,
                RedirectStandardOutput = true,
            };
            
            AppendLog("ExecuteShellCommand_processInfo.Arguments===>>" + processInfo?.Arguments);

            using (var process = Process.Start(processInfo))
            {
                if (process == null)
                {
                    AppendLog("无法启动进程");
                    return false;
                }

                process.OutputDataReceived += (object sender, DataReceivedEventArgs e) => { };
                process.BeginOutputReadLine();

                process.ErrorDataReceived += (object sender, DataReceivedEventArgs e) =>
                {
                    var errInfo = "error>>" + e.Data;
                    AppendLog(errInfo);
                };

                process.BeginErrorReadLine();

                process.WaitForExit();

                var exitCode = process.ExitCode;
                var exitInfo = $"ExitCode: {exitCode}";
                AppendLog(exitInfo);
                process.Close();

                return exitCode == 0;
            }
        }

        
        
        // 执行bat命令的方法
        public static bool ExecuteBatCommand(string command, string workingDirectory)
        {
            // 创建 ProcessStartInfo 对象
            var processInfo = new ProcessStartInfo("cmd.exe", "/c " + command)
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                WorkingDirectory = workingDirectory // 设置bat工作目录
            };
            AppendLog("ExecuteBatCommand_processInfo.Arguments===>>" + processInfo?.Arguments);
            // 启动进程
            using (var process = Process.Start(processInfo))
            {
                if (process == null)
                {
                    AppendLog("无法启动进程");
                    return false;
                }

                // 读取标准输出
                process.OutputDataReceived += (object sender, DataReceivedEventArgs e) =>
                {
                    if (!string.IsNullOrEmpty(e.Data))
                    {
                        AppendLog(e.Data);
                    }
                };
                process.BeginOutputReadLine();

                // 读取错误输出
                process.ErrorDataReceived += (object sender, DataReceivedEventArgs e) =>
                {
                    if (!string.IsNullOrEmpty(e.Data))
                    {
                        AppendLog($"error>>{e.Data}");
                    }
                };
                process.BeginErrorReadLine();

                // 等待进程退出
                process.WaitForExit();
                var exitCode = process.ExitCode;
                AppendLog($"ExitCode: {exitCode}");

                // 返回进程是否成功退出
                return exitCode == 0;
            }
        }
        #endregion
        
        public static async Task<string> SendBuildProgress(string sendContent)
        {

            if (!_isSendBuildProgress)
            {
                return string.Empty;
            }

            if (_client == null)
            {
                _client = new HttpClient();
            }

            var htMarkDownContent = new Hashtable();
            htMarkDownContent["content"] = sendContent;
            var hashTable = new Hashtable();
            hashTable["msgtype"] = "markdown";
            hashTable["markdown"] = htMarkDownContent;

            string json = JsonConvert.SerializeObject(hashTable);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync(webhookUrl, content);
            var responseString = await response.Content.ReadAsStringAsync();
            return responseString;
        }

        public static void DeleteDirectory(string targetDir)
        {
            if (!Directory.Exists(targetDir))
            {
                return;
            }

            if (Directory.Exists(targetDir))
            {
                Directory.Delete(targetDir, true);
            }
        }

        public static void MakeDirectory(string path)
        {
            var fi = new FileInfo(path);
            if (fi.Directory != null && !fi.Directory.Exists)
            {
                fi.Directory.Create();
            }
        }



        public static void CopyDirectory(string src, string dst)
        {
            var srcDir = new DirectoryInfo(src);
            var dstDir = new DirectoryInfo(dst);
            if (!srcDir.Exists)
            {
                return;
            }

            if (!dstDir.Exists)
            {
                dstDir.Create();
            }

            var srcDirFullName = srcDir.FullName;
            var dirFullName = dstDir.FullName;
            var srcDirLen = srcDirFullName.Length;
            var srcFiles = srcDir.GetFiles("*", SearchOption.AllDirectories);
            //拷贝当前目录下的子文件
            foreach (var file in srcFiles)
            {
                var dstFilename = dirFullName + file.FullName.Substring(srcDirLen);
                var dstFileInfo = new FileInfo(dstFilename);
                if (dstFileInfo.Directory != null && !dstFileInfo.Directory.Exists)
                {
                    dstFileInfo.Directory.Create();
                }

                File.Copy(file.FullName, dstFilename, true);
            }

            // 递归拷贝子目录
            foreach (DirectoryInfo subDirectory in srcDir.GetDirectories())
            {
                CopyDirectory(subDirectory.FullName, Path.Combine(dstDir.FullName, subDirectory.Name));
            }
        }

        public static bool RenameFile(string oldFilePath, string newFileName)
        {
            string directory = Path.GetDirectoryName(oldFilePath);
            string newFilePath = Path.Combine(directory, newFileName);

            if (File.Exists(newFilePath))
            {
                Console.WriteLine("目标文件已存在，无法重命名！");
                return false;
            }

            try
            {
                File.Move(oldFilePath, newFilePath);
                Console.WriteLine("文件重命名成功！");
                return true;

            }
            catch (Exception ex)
            {
                Console.WriteLine("文件重命名失败：" + ex.Message);
            }

            return false;
        }
        
        public static long PackNumber = 0;
        public static void WritePackVersion()
        {
            string file = GFileUtil.LocateFile("Assets/Code/GEnv.cs");
            if (!File.Exists(file))
            {
                GSQBuildMgr.AppendLog("Not Found GEnv.cs In Path ==>" + file);
                return;
            }

            var currTime = DateTime.Now.ToString("yyyyMMddHHmm");
            long.TryParse(currTime, out PackNumber);
            string txt = File.ReadAllText(file);
            // 使用正则表达式匹配并替换
            string pattern = @"(public const long PackVersion\s*=\s*)(\d+)(?=;)";

            string replacement = "${1}" + PackNumber; // 使用${1}来避免混淆

            string result = Regex.Replace(txt, pattern, replacement);
            File.WriteAllText(file, result);
        }

        #region 生成图集工具函数

        private static string _texlistPath = string.Empty;

        public static string TexListPath
        {
            get
            {
                if (string.IsNullOrEmpty(_texlistPath))
                {
                    _texlistPath = $"{AssetPathUtils.AssetPathPrefix}res/Sprs/texlist.txt";
                }

                return _texlistPath;
            }
        }

        private static string[] _resSprsFolders = new string[] {"res/Sprs", "res/Sprs_lod1", "res/Sprs_lod2"};


        [MenuItem("xasset/GenSpriteAndTextureLink(图集链接生成工具)")]
        public static void GenSpriteAndTextureLink()
        {
            GenerateSpriteAndTextureLink();
        }

        [MenuItem("xasset/GenTextureLink")]
        public static Boolean GenerateSpriteAndTextureLink()
        {
            try
            {
                var sb = new System.Text.StringBuilder();
                sb.AppendLine("Spr\tTex");
                foreach (var sprF in _resSprsFolders)
                {
                    var dirinfo = new DirectoryInfo(AssetPathUtils.AssetPathPrefix + sprF);
                    if (!dirinfo.Exists)
                        continue;
                    var allpngs = dirinfo.GetFiles("*.png", SearchOption.AllDirectories);
                    foreach (var fi in allpngs)
                    {
                        var path = fi.FullName.Replace("\\", "/");
                        var idx = path.LastIndexOf(sprF, StringComparison.Ordinal);
                        var checkpath = path.Substring(idx);
                        checkpath = checkpath.Substring(0, checkpath.Length - 4);
                        var assetPath = AssetPathUtils.FullPath2AssetPath(path);
                        var allAsset = AssetDatabase.LoadAllAssetsAtPath(assetPath);
                        if (allAsset.Length <= 0)
                        {
                            continue;
                        }

                        var sprites = new List<Sprite>();
                        foreach (var asset in allAsset)
                        {
                            if (asset is Sprite)
                            {
                                sprites.Add(asset as Sprite);
                            }
                        }

                        if (sprites.Count == 0)
                            continue;
                        var dir = checkpath.Substring(0, checkpath.LastIndexOf("/", StringComparison.Ordinal));
                        foreach (var s in sprites)
                        {
                            var dirname = dir + "/" + s.name;
                            if (s is Sprite /*&& dirname != checkpath*/)
                                sb.AppendFormat("{0}/{1}\t{2}\n", dir, s.name, checkpath);
                        }
                    }
                }

                if (sb.Length > 0)
                {
                    File.WriteAllText(TexListPath, sb.ToString());
                    File.WriteAllText(TexListPath, sb.ToString());
                    AssetDatabase.ImportAsset(TexListPath, ImportAssetOptions.ForceUpdate);
                    AssetDatabase.ImportAsset(TexListPath + ".meta", ImportAssetOptions.ForceUpdate);
                    AssetDatabase.Refresh();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                KLog.Err("GenerateSpriteAndTextureLink failed!");
            }

            return false;
        }


      
     
     #endregion

   

    
     
}
    
  
}


