using System;
using UnityEditor;
using xasset.editor;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessBundleBuildStep : GSQBuildStep
    {
        public ProcessBundleBuildStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }


        public override void OnStart()
        {
            base.OnStart();
            try
            {
                var sendProgress = GSQBuildMgr.SendBuildProgress(StepContent);
                AssetDatabase.Refresh();
                Builder.BuildBundles(Selection.GetFiltered<Build>(SelectionMode.DeepAssets));
                var buildSuccessContent  = $"<font color=\"warning\">#{GSQBuildMgr.SdkTypeStr} 版本构建核心步骤提示</font>\n <font color=\"info\">Great! {Name} 构建成功!</font> ";
                sendProgress = GSQBuildMgr.SendBuildProgress(buildSuccessContent);
                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }

        public override void OnEnd()
        {
            //TODO
            base.OnEnd();
        }


        private float _progress = 0.0f;

        public override float Progress => _progress;
    }
}