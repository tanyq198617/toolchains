using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using XiaWorld;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessTeachFileStep : GSQBuildStep
    {
        private bool ziptest = false;

        private string XiaWorldSlash = "/XiaWorld/";
        private string _teachFile4Zip = "4ZipTeachFile";
        private string _teachFile = "TeachFile";
        private string _wallPaper = "WallPaper";
        private string _teachFileSrcDir = "XiaWorld/TeachFile";
        private string _wallPaperSrcDir = "XiaWorld/WallPaper";
        private string _teachfileBytes = "TeachFile.bytes";


        private float _progress = 0.0f;
        public override float Progress => _progress;


        public ProcessTeachFileStep(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }


        public override void OnStart()
        {
            base.OnStart();

            try
            {
                var result = GSQBuildMgr.SendBuildProgress(StepContent);
                //var isTeachFileSuccess = OnProcessTeachFileWallPaper();
                var isTeachFileSuccess = GSQBuildMgr.OnProcessTeachFileWallPaper();
                if (!isTeachFileSuccess)
                {
                    SetResult(BuildResult.Failed, "OnProcessTeachFileWallPaper failed!");
                    GSQBuildMgr.AppendLog("OnProcessTeachFileWallPaper failed!");
                }

                SetResult(BuildResult.Success);
            }
            catch (Exception e)
            {
                SetResult(BuildResult.Failed, e.Message);
                throw;
            }
        }
        /*private bool OnProcessTeachFileWallPaper()
        {
            try
            {
                var teachFileFromFolder = GFileUtil.LocateFile(_teachFile);
                
                var teachFileDirInfo = new DirectoryInfo(teachFileFromFolder);
                var pRoot = teachFileDirInfo.Parent?.Parent;
                var p = new DirectoryInfo(pRoot?.FullName + "/" + _teachFile4Zip);
                var teachFileToFolder = p.FullName + "/" + _teachFile;

                var wallPaperFromFolder = pRoot?.FullName + "/" + _wallPaperSrcDir;
                var wallPaperToFolder = p.FullName + "/" + _wallPaper;

                GSQBuildMgr.AppendLog("< p=" + p + " teachFileFromFolder=" + teachFileFromFolder +
                                      " teachFileToFolder=" + teachFileToFolder + " wallPaperFromFolder=" +
                                      wallPaperFromFolder + " wallPaperToFolder==>" + wallPaperToFolder);

                var zipFile = pRoot?.FullName + XiaWorldSlash + AssetPathUtils.AssetPathPrefix + _teachfileBytes;

                if (ziptest)
                {
                    zipFile = pRoot?.FullName + "/" + _teachfileBytes;
                }

                if (!ziptest)
                {
                    if (p.Exists)
                        p.Delete(true);
                    p.Create();
                    GSQBuildMgr.CopyDirectory(teachFileFromFolder, teachFileToFolder);
                    GSQBuildMgr.CopyDirectory(wallPaperFromFolder, wallPaperToFolder);
                }


                ZipHelper.ZipNoTopDirectory(p.FullName, zipFile);
                //AssetDatabase.ImportAsset(AssetPathUtils.AssetPathPrefix + _teachfileBytes, ImportAssetOptions.ForceUpdate);
                //AssetDatabase.ImportAsset(AssetPathUtils.AssetPathPrefix + _teachfileBytes + ".meta", ImportAssetOptions.ForceUpdate);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                return true;
            }
            catch (Exception e)
            {
                GSQBuildMgr.AppendLog("ProcessTeachFile_e=>" + e.Message);
                return false;
            }

        }*/
        

        public override void OnEnd()
        {
            //TODO
            base.OnEnd();
        }
    }
}