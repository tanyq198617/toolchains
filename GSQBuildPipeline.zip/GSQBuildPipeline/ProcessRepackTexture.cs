﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace Code.Editor.GSQBuildPipeline
{
    public class ProcessRepackTexture : GSQBuildStep
    {
        public ProcessRepackTexture(int step, string descriptionKey) : base(step, descriptionKey)
        {
        }

        public static void Run(string tp,ref bool result)
		{
			var dic = SpriteMakeTool.GetMakeDic();
			SpriteMakeTool.MakeSprite(dic, tp, 1f, false);

			UnityEditor.AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);
			result = GSQBuildMgr.GenerateSpriteAndTextureLink();

            if (Application.isPlaying)
            {
				BuildMaskMaker.ExportBuildSpr();
			}
			BuildMaskMaker.MakeAllBuildMaskTex();
		}

		public override void OnStart()
        {
            base.OnStart();

            bool result = false;
            string errorMsg = null;
            if (IsRepackTexture)
            {
                var tp = TexturePackerexe;
                if (string.IsNullOrEmpty(tp))
                {
                    result = false;
                    errorMsg = "No TexturePacker";
                }
                else
                {
                    try
                    {
                        Run(tp,ref result);
					}
                    catch (System.Exception ex)
                    {
                        result = false;
                        errorMsg = ex.ToString();
                        Debug.LogError(errorMsg);
                    }
                }
            }
            else
            {
                result = GSQBuildMgr.GenerateSpriteAndTextureLink();
            }

            if (result)
            {
                SetResult(BuildResult.Success);
            }
            else
            {
                SetResult(BuildResult.Failed, errorMsg);
            }
        }
    }

    public class RepackTextureWindow : EditorWindow
	{
        public string TP = "D:/WorkSpace/TexturePacker4/bin/TexturePacker.exe";
        
        [MenuItem("JenkinsTest/一键图集")]
		public static void Create()
		{
            var wnd = EditorWindow.GetWindow<RepackTextureWindow>();
            wnd.Show();
		}

		void OnGUI()
        {
            GUILayout.BeginVertical();
			TP = GUILayout.TextField(TP);
			if (GUILayout.Button("Run"))
			{
                bool r = false;
                ProcessRepackTexture.Run(TP,ref r);
                GSQBuildMgr.GenerateSpriteAndTextureLink();
				this.Close();
			}
			GUILayout.EndVertical();
        }
	}
}